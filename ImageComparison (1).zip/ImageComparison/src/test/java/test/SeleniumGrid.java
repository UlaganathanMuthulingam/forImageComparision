package test;
import org.openqa.selenium.*;
import org.openqa.selenium.remote.DesiredCapabilities;
import java.net.MalformedURLException;
import java.net.URL;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.Assert;
import org.testng.annotations.*;

public class SeleniumGrid {

    WebDriver node1,node2;
    String baseURL;
   String node1URL = "http://192.168.43.182:5566/wd/hub";
   String node2URL="http://192.168.43.40:2213/wd/hub";
    

    @BeforeTest
    public void setUp() throws MalformedURLException {
        baseURL = "http://demo.guru99.com/test/guru99home/";
        DesiredCapabilities capability = DesiredCapabilities.chrome();
        capability.setBrowserName("chrome");
        capability.setPlatform(Platform.WINDOWS);
        
        DesiredCapabilities caps2 = DesiredCapabilities.firefox();
        caps2.setBrowserName("firefox");
        caps2.setPlatform(Platform.WINDOWS);
        caps2.setVersion("30.0");
        caps2.setCapability("marionette", false);
  
      /* for (int i = 0; i < 13; i++) {
    	   new RemoteWebDriver(new URL(node1URL), caps2);
	}*/
       // node1 = new RemoteWebDriver(new URL(node1URL), capability);
        node2=new RemoteWebDriver(new URL("http://localhost:4455/wd/hub"), capability);
    }

    @AfterTest
    public void afterTest() {
       // node1.quit();
       node2.quit();
    }
    
    public void sampleTest() {
       // node1.get(baseURL);
       node2.get(baseURL);

      /*  if (node1.getPageSource().contains("MOBILE TESTING")) {
            Assert.assertTrue(true, "Mobile Testing Link Found");
        } else {
            Assert.assertTrue(false, "Failed: Link not found");
        }*/

        if (node2.getPageSource().contains("MOBILE TESTING")) {
            Assert.assertTrue(true, "Mobile Testing Link Found");
        } else {
            Assert.assertTrue(false, "Failed: Link not found");
        }

        
    }

}

