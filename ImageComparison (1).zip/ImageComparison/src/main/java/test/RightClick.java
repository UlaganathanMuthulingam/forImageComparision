package test;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.Test;




public class RightClick {
	
	
	
	
	@Test
	public void testSrc() {
	DesiredCapabilities IEDesiredCapabilities = DesiredCapabilities.internetExplorer();

	IEDesiredCapabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
	IEDesiredCapabilities.setCapability(InternetExplorerDriver.INITIAL_BROWSER_URL, "http://www.google.com");
	IEDesiredCapabilities.internetExplorer().setCapability("ignoreProtectedModeSettings", true);
	IEDesiredCapabilities.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
	IEDesiredCapabilities.setJavascriptEnabled(true);
	//IEDesiredCapabilities.setCapability("requireWindowFocus", true);
	IEDesiredCapabilities.setCapability("enablePersistentHover", false);

	System.setProperty("webdriver.ie.driver", "./drivers/iedriver.exe");
	//  SpyerCore X = new SpyerCore();
	WebDriver driver =  new InternetExplorerDriver(IEDesiredCapabilities);
	// X.setDriver(driver);
	//X.loadURL("http://localhost:8080/Test_Web_App/");

	/*System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
	WebDriver driver = new ChromeDriver();
	*/
	driver.get("D:\\நிர்வாகம் - தேதி.html");
//	WebElement btnLogin=driver.findElement(By.id("btnLogin"));
	
	//Initialize Actions class object
   // Actions builder = new Actions(driver);
    
    // Perform Right Click on  MEN and  Open "Men" content in a new tab 
  //  builder.contextClick(btnLogin).sendKeys(Keys.ARROW_DOWN).sendKeys(Keys.ENTER).perform();
    //ContextClick() is a method to use right click 
	
	}

	
}
