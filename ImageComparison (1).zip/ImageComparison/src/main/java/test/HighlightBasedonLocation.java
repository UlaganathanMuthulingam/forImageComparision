package test;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.Test;

import com.maveric.webelementComparison.SpyerWebElementCast;

public class HighlightBasedonLocation {

	
	public static WebDriver HighlightElement(WebDriver driver, WebElement element){ 
	    if (driver instanceof JavascriptExecutor) {
	        ((JavascriptExecutor)driver).executeScript("arguments[0].style.border='3px solid red'", element);
	    }
	    return driver;
	}
	public static WebDriver UnhighlightElement(WebDriver driver, WebElement element){   
	    if (driver instanceof JavascriptExecutor) {    
	        ((JavascriptExecutor)driver).executeScript("arguments[0].style.border=''", element);
	    }
	    return driver;  
	}

	@Test(priority=1)
	public void takeScreenshotOfAllElementsPage1() throws IOException {
		//String searchString = "Navigate from Chennai to Madurai";
		DesiredCapabilities IEDesiredCapabilities = DesiredCapabilities.internetExplorer();
		List<WebElement> AllElementsofPage;
		IEDesiredCapabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		IEDesiredCapabilities.setCapability(InternetExplorerDriver.INITIAL_BROWSER_URL, "http://www.google.com");
		IEDesiredCapabilities.internetExplorer().setCapability("ignoreProtectedModeSettings", true);
		IEDesiredCapabilities.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
		IEDesiredCapabilities.setJavascriptEnabled(true);
		//IEDesiredCapabilities.setCapability("requireWindowFocus", true);
		IEDesiredCapabilities.setCapability("enablePersistentHover", false);

		System.setProperty("webdriver.ie.driver", "./drivers/iedriver.exe");
		//  SpyerCore X = new SpyerCore();
		WebDriver driver =  new InternetExplorerDriver(IEDesiredCapabilities);
		// X.setDriver(driver);
		//X.loadURL("http://localhost:8080/Test_Web_App/");

		driver.get("http://demo.rapidtestpro.com/admin");
		AllElementsofPage=driver.findElements(By.xpath("//*"));
		for (int j = 1; j < AllElementsofPage.size(); j++) {
			WebElement webElement = AllElementsofPage.get(j);
			SpyerWebElementCast ELementName = new SpyerWebElementCast(webElement);
		//	ELementName.setElementName("Snap"+ webElement.getLocation());
			//Point p=webElement.getLocation();
			HighlightElement(driver,webElement);
		}


	}


}
