package test;

import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

import org.apache.commons.collections4.CollectionUtils;
import org.openqa.selenium.Point;

public class MapComparison {
	
	public static void main(String[] args) {
		
		Set<String> notAligned = new HashSet<String>();
		Map<String, String> src = new HashMap<String, String>();
		src.put("A", "1");
		src.put("B", "2");
		//src.put("C", "3");
		Map<String, String> target = new HashMap<String, String>();
		target.put("A", "1");
		target.put("B", "2");
		target.put("c", "3");
		
		
		
	 notAligned= equalMaps(src,target);
	 for (String string : notAligned) {
		 System.out.println(string);
	}
	
		
	}

		
	public static Set<String> equalMaps(Map<String,String>src, Map<String,String>target) {
		
		Set<String> mismatchedKeys = new HashSet<String>();
		Set<String> notAligned = new HashSet<String>();
		//check both maps are equal
		if(src.equals(target)) {
			
			System.out.println("No Alignment issue");
		}
		
		//If  Both Maps are not equal
		else {
			
		//check if the key set are same			
		if(target.keySet().equals(src.keySet())) {
  
			System.out.println("Keyset same");
			
		for (String key: src.keySet()) {
		      if (!src.get(key).equals(target.get(key))) {
		    	  notAligned.add(key); 
		    	//System.out.println(key);  
		      }
		      
		   		   } 
		  
		}
		
		else if(!target.keySet().equals(src.keySet())) {
			System.out.println("Keyset not same");
			
			for (String key: src.keySet()) {
			      if (!target.containsKey(key)) {
			    	  System.out.println("The element with xpath " + key + "is missing in the target");
			    	//System.out.println(key);  
			      }
			      
			   		   } 
			
			for (String key: target.keySet()) {
			      if (!src.containsKey(key)) {
			    	  System.out.println("The element with xpath " + key + "is added extra in the target");
			    	//System.out.println(key);  
			      }
			      
			   		   } 
		
		
		/*	Collection<String> dis= CollectionUtils.disjunction(src.keySet(), target.keySet());	
			for (String string : dis) {
				System.out.println("hi" + string);
			}
			
		*/	
			
		}
			
		

		
}

		return notAligned;
	}
	
}