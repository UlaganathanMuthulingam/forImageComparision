package test;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.imageio.ImageIO;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.By.ById;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.Point;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.Test;

import com.maveric.webelementComparison.SpyerWebElementCast;

import ru.yandex.qatools.ashot.AShot;
import ru.yandex.qatools.ashot.Screenshot;



public class PageSpyer {


	String RepositoryDirectoryPathSrc = "D:\\SpyerRepository\\Src";
	String RepositoryDirectoryPathTarget = "D:\\SpyerRepository\\Target";
	public boolean base64stitch = false;
	List<WebElement> AllElementsofPage;
	List<WebElement> AllElementsofTargetPage;
	static Map<String,Point> srcMap=new HashMap<String,Point>();
	static Map<String,Point> targetMap=new HashMap<String,Point>();

	public synchronized String elementScreenShot(WebElement ele, WebDriver driver,String FileName,String Path) throws IOException {
		//String Destinationpath = Path + "\\" + ele.getTagName() + "\\" + FileName + ".png";
		String Destinationpath = Path + "\\" + FileName + ".png";
		try {
			
						
			// Get entire page screenshot
			File screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			BufferedImage fullImg = ImageIO.read(screenshot);

			// Get the location of element on the page
			Point point = ele.getLocation();

			// Get width and height of the element
			int eleWidth = ele.getSize().getWidth();
			int eleHeight = ele.getSize().getHeight();

			// Crop the entire page screenshot to get only element screenshot
			BufferedImage eleScreenshot = fullImg.getSubimage(point.getX(), point.getY(),
					eleWidth, eleHeight);
			System.out.println("");
			ImageIO.write(eleScreenshot, "png", screenshot);

			// Copy the element screenshot to disk
			File screenshotLocation = new File(Destinationpath);
			FileUtils.copyFile(screenshot, screenshotLocation);
			/*if (base64stitch == true) {
				FileInputStream FIS = new FileInputStream(screenshot);
				byte[] bytes = new byte[(int) screenshot.length()];
				FIS.read(bytes);
				Destinationpath = "data:image/png;base64," + new String(Base64.encodeBase64(bytes));
			}
*/
		} catch (Exception Ex) {
			// Ex.printStackTrace();
		} finally {
			return Destinationpath;
		}
	}


@Test(priority=1)
	public void takeScreenshotOfAllElementsPage1() throws IOException {
		
		DesiredCapabilities IEDesiredCapabilities = DesiredCapabilities.internetExplorer();

		IEDesiredCapabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		IEDesiredCapabilities.setCapability(InternetExplorerDriver.INITIAL_BROWSER_URL, "http://www.google.com");
		IEDesiredCapabilities.internetExplorer().setCapability("ignoreProtectedModeSettings", true);
		IEDesiredCapabilities.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
		IEDesiredCapabilities.setJavascriptEnabled(true);
		//IEDesiredCapabilities.setCapability("requireWindowFocus", true);
		IEDesiredCapabilities.setCapability("enablePersistentHover", false);

		System.setProperty("webdriver.ie.driver", "./drivers/iedriver.exe");
		
		WebDriver driver =  new InternetExplorerDriver(IEDesiredCapabilities);
		

		driver.get("http://demo.rapidtestpro.com/admin");
		AllElementsofPage=driver.findElements(By.xpath("//*"));
		for (int j = 1; j < AllElementsofPage.size(); j++) {
			WebElement webElement = AllElementsofPage.get(j);
			SpyerWebElementCast ELementName = new SpyerWebElementCast(webElement);
			ELementName.setElementName("Snap"+ j);
			srcMap.put(ELementName.getElementName(), webElement.getLocation());
			elementScreenShot(ELementName.getELement(), driver,ELementName.getElementName(),RepositoryDirectoryPathSrc); 
		}
		for (Entry<String, Point> entry: srcMap.entrySet()) {
			String key=entry.getKey();
			Point value=entry.getValue();
			System.out.println("Srckey " + key + "-->" + value);
			
		}
		
	}


@Test(priority=2)
public void takeScreenshotOfAllElementsPage2() throws IOException {
	
	DesiredCapabilities IEDesiredCapabilities = DesiredCapabilities.internetExplorer();

	IEDesiredCapabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
	IEDesiredCapabilities.setCapability(InternetExplorerDriver.INITIAL_BROWSER_URL, "http://www.google.com");
	IEDesiredCapabilities.internetExplorer().setCapability("ignoreProtectedModeSettings", true);
	IEDesiredCapabilities.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
	IEDesiredCapabilities.setJavascriptEnabled(true);
	//IEDesiredCapabilities.setCapability("requireWindowFocus", true);
	IEDesiredCapabilities.setCapability("enablePersistentHover", false);

	System.setProperty("webdriver.ie.driver", "./drivers/iedriver.exe");
	//  SpyerCore X = new SpyerCore();
	WebDriver driver =  new InternetExplorerDriver(IEDesiredCapabilities);
	// X.setDriver(driver);
	//X.loadURL("http://localhost:8080/Test_Web_App/");

	driver.get("http://demo.rapidtestpro.com/admin");
	AllElementsofTargetPage=driver.findElements(By.xpath("//*"));
	for (int k = 1; k < AllElementsofTargetPage.size(); k++) {
		WebElement webElement = AllElementsofTargetPage.get(k);
		SpyerWebElementCast ELementName = new SpyerWebElementCast(webElement);
		ELementName.setElementName("Snap"+ k);
		targetMap.put(ELementName.getElementName(), webElement.getLocation());
		elementScreenShot(ELementName.getELement(), driver,ELementName.getElementName(),RepositoryDirectoryPathTarget); 
	}
	
	for (Entry<String, Point> entry: targetMap.entrySet()) {
		String key=entry.getKey();
		Point value=entry.getValue();
		System.out.println("Targetkey " + key + "-->" + value);
		
	}
	
	
if(targetMap.equals(srcMap)) {
		
		System.out.println("************No Alignment issue found***********************");
	}
	
}


/*@Test(priority=2)
public void takeScreenshotOfAllElementsTarget() throws IOException {
	
	DesiredCapabilities IEDesiredCapabilities = DesiredCapabilities.internetExplorer();

	IEDesiredCapabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
	IEDesiredCapabilities.setCapability(InternetExplorerDriver.INITIAL_BROWSER_URL, "http://www.google.com");
	IEDesiredCapabilities.internetExplorer().setCapability("ignoreProtectedModeSettings", true);
	IEDesiredCapabilities.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
	IEDesiredCapabilities.setJavascriptEnabled(true);
	//IEDesiredCapabilities.setCapability("requireWindowFocus", true);
	IEDesiredCapabilities.setCapability("enablePersistentHover", false);

	System.setProperty("webdriver.ie.driver", "./drivers/iedriver.exe");
	//  SpyerCore X = new SpyerCore();
	WebDriver driver =  new InternetExplorerDriver(IEDesiredCapabilities);
	// X.setDriver(driver);
	//X.loadURL("http://localhost:8080/Test_Web_App/");

	driver.get("http://demo.rapidtestpro.com/admin");
	AllElementsofTargetPage=driver.findElements(By.xpath("//*"));
	
	for (WebElement listwebElement : AllElementsofTargetPage) {
		System.out.println(listwebElement);
	}
	
	for (Entry<String, Point> entry: srcMap.entrySet()) {
		String srcWebElement=entry.getKey();
		Point srcLocation=entry.getValue();
		System.out.println("srcWebElement" + srcWebElement);
		System.out.println("srcLocation" + srcLocation);
		
		if(AllElementsofTargetPage.contains(srcWebElement)) {
			System.out.println("i am here");
			for (int j = 1; j < AllElementsofPage.size(); j++) {
				WebElement targetWebElement = AllElementsofPage.get(j);
				Point targetLocation=targetWebElement.getLocation();
				if(srcLocation.equals(targetLocation)) {
				System.out.println("location same");	
				}
				
				else
				{
					System.out.println("location different");
					System.out.println("srcLocation " + srcLocation + "targetLocation" + targetLocation );
				}
				}
		}
		//System.out.println("Key, " + key+ "value" + value);
	}
//		

}
*/


}