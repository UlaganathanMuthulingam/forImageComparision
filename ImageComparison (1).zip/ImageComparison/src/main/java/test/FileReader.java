package test;
import java.io.File;
import java.io.IOException;
/**
 * Contains some methods to list files and folders from a directory
 *
 * @author Loiane Groner
 * http://loiane.com (Portuguese)
 * http://loianegroner.com (English)
 */
public class FileReader {
	/**
	 * List all the files and folders from a directory
	 * @param directoryName to be listed
	 */
	public void listFilesAndFolders(String directoryName){
		File directory = new File(directoryName);
		//get all the files from a directory
		File[] fList = directory.listFiles();
		for (File file : fList){
			System.out.println(file.getName());
		}
	}
	/**
	 * List all the files under a directory
	 * @param directoryName to be listed
	 */
	public void listFiles(String directoryName){
		File directory = new File(directoryName);
		//get all the files from a directory
		File[] fList = directory.listFiles();
	

		for (File file : fList){
			if (file.isFile()){
				System.out.println(file.getName());
			}
		}
	}

	/**
	 * List only the first file under a directory
	 * @param directoryName to be listed
	 * @throws IOException 
	 */
	public String listFirstFile(String directoryName) throws IOException{
		File directory = new File(directoryName);
		//get  the first file from a directory
		File[] fList = directory.listFiles();
		File firstFile = null;
		if(fList.length!=0)
		{
			firstFile = fList[0]; }


		return firstFile.getCanonicalPath();

	}



	/**
	 * List all the folder under a directory
	 * @param directoryName to be listed
	 */
	public void listFolders(String directoryName){
		File directory = new File(directoryName);
		//get all the files from a directory
		File[] fList = directory.listFiles();
		for (File file : fList){
			if (file.isDirectory()){
				System.out.println(file.getName());
			}
		}
	}
	/**
	 * List all files from a directory and its subdirectories
	 * @param directoryName to be listed
	 */
	public void listFilesAndFilesSubDirectories(String directoryName){
		File directory = new File(directoryName);
		//get all the files from a directory
		File[] fList = directory.listFiles();
		for (File file : fList){
			if (file.isFile()){
				System.out.println(file.getAbsolutePath());
			} else if (file.isDirectory()){
				listFilesAndFilesSubDirectories(file.getAbsolutePath());
			}
		}
	}
	public static void main (String[] args) throws IOException{
		FileReader listFilesUtil = new FileReader();
		//Imagedecoder X = new Imagedecoder();
		//final String directoryLinuxMac ="/Users/loiane/test";
		//Windows directory example
		final String SrcDirectory ="D:\\SpyerRepository\\Src";
		final String TargetDirectory="D:\\SpyerRepository\\Target";
		String srcFirstFile=listFilesUtil.listFirstFile(SrcDirectory);
		String targetFirstFile=listFilesUtil.listFirstFile(TargetDirectory);
		System.out.println("srcFirstFile is" + srcFirstFile);
		System.out.println("targetFirstFile is" + targetFirstFile);
		//if(srcFirstFile..equalsIgnoreCase(targetFirstFile))
		//{
			
			Boolean result=Imagedecoder.validateImagePixels(srcFirstFile,targetFirstFile);
			System.out.println("hi" + result);
			Float rgbresult=Imagedecoder.compareImageRGBData(srcFirstFile,targetFirstFile);
			System.out.println("hi1" + rgbresult);
	//}
	}
}


