/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test;


import java.awt.Image;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.awt.image.PixelGrabber;
import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;


public class Imagedecoder {

	static boolean validateImagePixels(String File1, String File2) {
	
		boolean result = false;
		try {

			Image image1 = Toolkit.getDefaultToolkit().getImage(File1);
			Image image2 = Toolkit.getDefaultToolkit().getImage(File2);

			PixelGrabber grab1 = new PixelGrabber(image1, 0, 0, -1, -1, false);
			PixelGrabber grab2 = new PixelGrabber(image2, 0, 0, -1, -1, false);
			int[] data1 = null;
			if (grab1.grabPixels()) {
				int width = grab1.getWidth();
				int height = grab1.getHeight();
				data1 = new int[width * height];
				data1 = (int[]) grab1.getPixels();
			}
			int[] data2 = null;
			if (grab2.grabPixels()) {
				int width = grab2.getWidth();
				int height = grab2.getHeight();
				data2 = new int[width * height];
				data2 = (int[]) grab2.getPixels();
			}
			/*for (int i = 0; i < data1.length; i++) {
                System.out.println(data1[i]);
            }
            for (int i = 0; i < data1.length; i++) {
                System.out.println(data2[i]);
            }*/
			result = java.util.Arrays.equals(data1, data2);
			//System.out.println("Pixels equal: " + result);
		} catch (InterruptedException ex) {
			Logger.getLogger(Imagedecoder.class.getName()).log(Level.SEVERE, null, ex);
		}
		return result;
	}

	public static float compareImageRGBData(String File1, String File2) throws IOException {
		float x;
		int largerwidth, largerheight;
		long start = System.currentTimeMillis();
		File file = new File(File1);
		File files = new File(File2);
		File Result = new File("D:\\Priya\\imagecomparison\\Comparisonresult.png");
		BufferedImage resultimage = ImageIO.read(file);
		BufferedImage image = ImageIO.read(file);
		int width = image.getWidth(null);
		int height = image.getHeight(null);
		int[][] clr = new int[width][height];
		BufferedImage images = ImageIO.read(files);
		if (image.equals(images)) {
			System.out.println("Buffered Image Object is equal");
		}
		int widthe = images.getWidth(null);
		int heighte = images.getHeight(null);
		int[][] clre = new int[widthe][heighte];
		int smw = 0;
		int smh = 0;
		int p = 0;
		//CALUCLATING THE SMALLEST VALUE AMONG WIDTH AND HEIGHT
		if (width > widthe) {
			smw = widthe;
			largerwidth = width;
		} else {
			smw = width;
			largerwidth = widthe;
		}
		if (height > heighte) {
			smh = heighte;
			largerheight = height;
		} else {
			smh = height;
			largerheight = heighte;
		}
		//CHECKING NUMBER OF PIXELS SIMILARITY
		for (int a = 0; a < smw; a++) {
			for (int b = 0; b < smh; b++) {
				clre[a][b] = images.getRGB(a, b);
				clr[a][b] = image.getRGB(a, b);
				if (clr[a][b] == clre[a][b]) {
					// System.out.println("Equal(" + a + "," + b + ") : Image 1 :" + clr[a][b] + " Image 2 :" + clre[a][b]);
					p = p + 1;
				} else {
					//red 
					resultimage.setRGB(a, b, -1237980);
					//resultimage.setRGB(a, b, 16761035);
				}
			}
		}
	/*	System.out.println("Smallwidth : " + smw + "|| Largerwidth :" + largerwidth);
		System.out.println("Smallheight : " + smh + "|| Largerheight :" + largerheight);*/
		
		float w, h = 0;
		if (width > widthe) {
			w = width;
		} else {
			w = widthe;
		}
		if (height > heighte) {
			h = height;
		} else {
			h = heighte;
		}
		float s = (smw * smh);
		//CALUCLATING PERCENTAGE
		x = (100 * p) / s;
		ImageIO.write(resultimage, "png", Result);
		System.out.println("THE PERCENTAGE SIMILARITY IS APPROXIMATELY =" + x + "%");
		long stop = System.currentTimeMillis();
		System.out.println("TIME TAKEN IS =" + (stop - start) +"ms");
		return x;
	}

	public static void main(String[] args) throws IOException {
	String	file1 = "D:\\Priya\\imagecomparison\\1.png";
	String	file2 = "D:\\Priya\\imagecomparison\\2.png";
		System.out.println("Do the Images Match : "+validateImagePixels(file1, file2));
		System.out.println("Comapare RGB Data"+ compareImageRGBData(file1, file2));

	}
}
