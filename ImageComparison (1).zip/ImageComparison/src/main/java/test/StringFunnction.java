package test;

public class StringFunnction {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
String key= "*//td[text()=':: Admin Login ::']";
if(key!=null && key.contains("text()"))
    System.out.println("Plain-Text");
else
	System.out.println("not woekinmg");

	}

}
