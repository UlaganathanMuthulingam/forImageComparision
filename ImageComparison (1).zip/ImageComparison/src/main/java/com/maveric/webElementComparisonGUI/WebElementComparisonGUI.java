package com.maveric.webElementComparisonGUI;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import javax.swing.JSplitPane;
import javax.swing.JComboBox;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;

import com.beust.testng.TestNG;
import com.maveric.webelementComparison.SourcePageSpyer2;
import com.maveric.webelementComparison.TargetPageSpyer2;

import javax.swing.JProgressBar;
import javax.swing.JLabel;

public class WebElementComparisonGUI {

	private JFrame frame;
	private JTextField textField;
	private JTextField textField_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					WebElementComparisonGUI window = new WebElementComparisonGUI();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public WebElementComparisonGUI() {
		initialize();
	}

	

	/**
	 * Initialize the contents of the frame.
	 * @throws Exception 
	 */
	private void launchbrowserActionPerformed(ActionEvent evt) throws Exception {
		String Selected_Browser = comboBox.getSelectedItem().toString();
	//	SourcePageSpyer2.browser=Selected_Browser;
	new SourcePageSpyer2().scanSrcPage(Selected_Browser,textField.getText());
	
	/*	TestNG X = new TestNG();
		Class[] listofclasses = {SourcePageSpyer2.class};
		X.setTestClasses(listofclasses);
		X.run();
	*/	}

	
	private void targetURLActionPerformed(ActionEvent evt) throws Exception {
		String Selected_Browser = comboBox.getSelectedItem().toString();
		TargetPageSpyer2.browser=Selected_Browser;
	//new TargetPageSpyer2().scanTargetPage(textField_1.getText());
		TargetPageSpyer2.URL=textField_1.getText();
		TestNG X = new TestNG();
		Class[] listofclasses = {TargetPageSpyer2.class};
		X.setTestClasses(listofclasses);
		X.run();
		}

JComboBox comboBox = new JComboBox();
private JTextField textField_2;
	private void initialize() {
		
		frame = new JFrame();
		frame.setBounds(100, 100, 466, 450);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		comboBox.setBounds(10, 71, 162, 20);
		comboBox.addItem("Internet Explorer");
		comboBox.addItem("Chrome");
		frame.getContentPane().add(comboBox);
		
		JButton btnLaunchBrowser = new JButton("Generate BaseLine File For URL");
		btnLaunchBrowser.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				
				try {
					launchbrowserActionPerformed(evt);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});
		btnLaunchBrowser.setBounds(128, 128, 213, 23);
		frame.getContentPane().add(btnLaunchBrowser);
		
		textField = new JTextField();
		textField.setBounds(228, 71, 198, 20);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		JLabel lblSrcUrlProcessing = new JLabel("Target URL to Test");
		lblSrcUrlProcessing.setBounds(10, 162, 124, 14);
		frame.getContentPane().add(lblSrcUrlProcessing);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(10, 187, 198, 20);
		frame.getContentPane().add(textField_1);
		
		JLabel lblTargetUrlProcessing = new JLabel("BaseLine File");
		lblTargetUrlProcessing.setBounds(229, 162, 124, 14);
		frame.getContentPane().add(lblTargetUrlProcessing);
		
		JButton btnTest = new JButton("Test");
		btnTest.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {
					targetURLActionPerformed(e);
				} catch (Exception exp) {
					// TODO Auto-generated catch block
					exp.printStackTrace();
				}
			}
		});
		btnTest.setBounds(137, 268, 188, 23);
		frame.getContentPane().add(btnTest);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(228, 187, 198, 20);
		frame.getContentPane().add(textField_2);
		
		JLabel lblBrowser = new JLabel("Browser");
		lblBrowser.setBounds(10, 32, 124, 14);
		frame.getContentPane().add(lblBrowser);
		
		JLabel lblUrl = new JLabel("Source URL");
		lblUrl.setBounds(229, 32, 124, 14);
		frame.getContentPane().add(lblUrl);
	}
}
