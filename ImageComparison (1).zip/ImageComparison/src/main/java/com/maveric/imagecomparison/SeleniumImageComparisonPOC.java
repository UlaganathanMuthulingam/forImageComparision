package com.maveric.imagecomparison;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.Test;

public class SeleniumImageComparisonPOC {
	public  RemoteWebDriver driver;
	public static String file1,file2;
	
	
	@Test(priority=1)
	public void startEnglishApp() throws InterruptedException {
		System.setProperty("webdriver.ie.driver", "./drivers/iedriver.exe");
		driver = new InternetExplorerDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.get("https://www.google.com/");
		WebElement textbox =driver.findElement(By.id("lst-ib"));
		textbox.sendKeys("Maveric");
		textbox.sendKeys(Keys.ENTER);
		Thread.sleep(2000);
		 file1=takeSnap();
		 driver.quit();
		// System.out.println(file1);
		
	}
	
	//@Test(priority=2)
	public void startEnglishAppAgain() throws InterruptedException {
		System.setProperty("webdriver.ie.driver", "./drivers/iedriver.exe");
		driver = new InternetExplorerDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.get("https://www.google.com/");
		WebElement textbox =driver.findElement(By.id("lst-ib"));
		textbox.sendKeys("Maveric");
		textbox.sendKeys(Keys.ENTER);
		Thread.sleep(2000);
		 file2=takeSnap();
		 driver.quit();
		// System.out.println(file2);
		
	}
	//@Test(priority=2)
	public void startEnglishAppChrome() throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		ChromeOptions options=new ChromeOptions();
		options.setExperimentalOption("useAutomationExtension", false);
		driver = new ChromeDriver(options);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.get("https://www.google.com/");
		WebElement textbox =driver.findElement(By.id("lst-ib"));
		textbox.sendKeys("hello");
		textbox.sendKeys(Keys.ENTER);
		Thread.sleep(2000);
		 file2=takeSnap();
		// System.out.println(file2);
		
	}
	
	@Test(priority=2)
	public void startTamilApp() throws InterruptedException {
		System.setProperty("webdriver.ie.driver", "./drivers/iedriver.exe");
		driver = new InternetExplorerDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.get("https://www.google.com/");
		driver.findElementByLinkText("தமிழ்").click();
		WebElement textbox =driver.findElement(By.id("lst-ib"));
		textbox.sendKeys("Maveric");
		textbox.sendKeys(Keys.ENTER);
		Thread.sleep(2000);
		 file2=takeSnap();
		// System.out.println(file2);	 
	}
	
 @Test(priority=3)
	public void compareImages() throws IOException {
	float differenceVal=Imagedecoder.compareImageRGBData(file1, file2);
	boolean imageMatch= Imagedecoder.validateImagePixels(file1, file2);
	System.out.println("Similarity Percentage between the images "+ differenceVal);
	System.out.println("Are the images identical ? "+ imageMatch);
	
 }
	public String takeSnap(){
			String number = new SimpleDateFormat("yyyyMMdd_hhmmss_SSS").format(new Date());
			String path="./images/"+number+".png";
			
			try {
				File file=driver.getScreenshotAs(OutputType.FILE);
				FileUtils.copyFile(file , new File(path));
				
			} catch (WebDriverException e) {
				System.out.println("The browser has been closed.");
				throw e;
			} catch (IOException e) {
				System.out.println("The snapshot could not be taken");

			}
			return path;
		}
}