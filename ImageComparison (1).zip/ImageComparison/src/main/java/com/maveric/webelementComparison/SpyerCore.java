/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.maveric.webelementComparison;

//import com.praveen.psr.spyerGUI.spyerGUI;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.Point;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

/**
 *
 * @author temp
 */
public class SpyerCore {

    public int progresspercent = 0;
    private float totalprogresscount = 0;
    private float currentprogress = 0;
    public WebDriver driver = null;
    public static String RepositoryDirectoryPath = "D:\\SpyerRepository";
   // public spyerGUI GUIObject = null;
    HashMap<String, HashMap<String, ArrayList<SpyerWebElementCast>>> AttributesMap;
    HashMap<String, String> RelativeAbsoluteMapping = new HashMap<String, String>();
    ArrayList<SpyerWebElementCast> SpyerElements = new ArrayList<SpyerWebElementCast>();
    List<WebElement> AllElementsofPage;
    String FileFormatDate = "";
    public boolean base64stitch = false;
    public boolean OnlyChildless = false, OnlyDisplayed = true;
    private long Secondstimetaken = 0;
    public String ReportURL = "";

    int k;

    public synchronized String elementScreenShot(WebElement ele, WebDriver driver, String Filename) throws IOException {
        String Destinationpath = this.RepositoryDirectoryPath + "\\" + ele.getTagName() + "\\" + Filename + ".png";
        try {
// Get entire page screenshot
            File screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
            BufferedImage fullImg = ImageIO.read(screenshot);

// Get the location of element on the page
            Point point = ele.getLocation();

// Get width and height of the element
            int eleWidth = ele.getSize().getWidth();
            int eleHeight = ele.getSize().getHeight();

// Crop the entire page screenshot to get only element screenshot
            BufferedImage eleScreenshot = fullImg.getSubimage(point.getX(), point.getY(),
                    eleWidth, eleHeight);
            ImageIO.write(eleScreenshot, "png", screenshot);

// Copy the element screenshot to disk
            File screenshotLocation = new File(Destinationpath);
            FileUtils.copyFile(screenshot, screenshotLocation);
            if (base64stitch == true) {
                FileInputStream FIS = new FileInputStream(screenshot);
                byte[] bytes = new byte[(int) screenshot.length()];
                FIS.read(bytes);
                Destinationpath = "data:image/png;base64," + new String(Base64.encodeBase64(bytes));
            }

        } catch (Exception Ex) {
            // Ex.printStackTrace();
        } finally {
            return Destinationpath;
        }
    }

  /*  public void TakeDriverSnap(String SnapPath) {
        try {
            TakesScreenshot Scrn = ((TakesScreenshot) driver);
            File SrcFile = Scrn.getScreenshotAs(OutputType.FILE);
            File DestinationScrnshtfile = new File(SnapPath);
            FileUtils.copyFile(SrcFile, DestinationScrnshtfile);
        } catch (IOException ex) {
            Logger.getLogger(SpyerCore.class.getName()).log(Level.SEVERE, null, ex);
        }
    }*/

    public String getXpath(WebElement ele) {
        String str = ele.toString();
        String[] listString = null;
        if (str.contains("xpath")) {
            listString = str.split("xpath:");
        } else if (str.contains("id")) {
            listString = str.split("id:");
        }
        String last = listString[1].trim();
        return last.substring(0, last.length() - 1);
    }

    public String getAbsoluteXPath(WebElement element, WebDriver driver) {
        return (String) ((JavascriptExecutor) driver).executeScript(
                "function absoluteXPath(element) {"
                + "var comp, comps = [];"
                + "var parent = null;"
                + "var xpath = '';"
                + "var getPos = function(element) {"
                + "var position = 1, curNode;"
                + "if (element.nodeType == Node.ATTRIBUTE_NODE) {"
                + "return null;"
                + "}"
                + "for (curNode = element.previousSibling; curNode; curNode = curNode.previousSibling) {"
                + "if (curNode.nodeName == element.nodeName) {"
                + "++position;"
                + "}"
                + "}"
                + "return position;"
                + "};"
                + "if (element instanceof Document) {"
                + "return '/';"
                + "}"
                + "for (; element && !(element instanceof Document); element = element.nodeType == Node.ATTRIBUTE_NODE ? element.ownerElement : element.parentNode) {"
                + "comp = comps[comps.length] = {};"
                + "switch (element.nodeType) {"
                + "case Node.TEXT_NODE:"
                + "comp.name = 'text()';"
                + "break;"
                + "case Node.ATTRIBUTE_NODE:"
                + "comp.name = '@' + element.nodeName;"
                + "break;"
                + "case Node.PROCESSING_INSTRUCTION_NODE:"
                + "comp.name = 'processing-instruction()';"
                + "break;"
                + "case Node.COMMENT_NODE:"
                + "comp.name = 'comment()';"
                + "break;"
                + "case Node.ELEMENT_NODE:"
                + "comp.name = element.nodeName;"
                + "break;"
                + "}"
                + "comp.position = getPos(element);"
                + "}"
                + "for (var i = comps.length - 1; i >= 0; i--) {"
                + "comp = comps[i];"
                + "xpath += '/' + comp.name.toLowerCase();"
                + "if (comp.position !== null) {"
                + "xpath += '[HashMap' + comp.position + ']';"
                + "}"
                + "}"
                + "return xpath;"
                + "} return absoluteXPath(arguments[0]);", element);
    }

   /* public void setProgressPercent() {
        System.out.println("Progress percent : " + progresspercent + " %");
        this.GUIObject.processingprogressbar.setValue(progresspercent);
        if (progresspercent == 100) {
            this.GUIObject.progressinfolabel.setText("Processed  (" + progresspercent + "%) and Report Generated | Time Taken : " + Secondstimetaken + " second(s)");
        } else {
            this.GUIObject.progressinfolabel.setText("Processing  (" + progresspercent + "%)");
        }
    }
*/
    public void openReportonBrowser() {
        this.driver.get(ReportURL);
    }

    HashMap<String, SpyerWebElementCast> ExcelOutPutMap = new HashMap<String, SpyerWebElementCast>();

    public HashMap<String,SpyerWebElementCast> generateRelativeXPath(String inputType) {
        RepositoryDirectoryPath = RepositoryDirectoryPath + "\\" +inputType;

        for (int i = 0; i < SpyerElements.size(); i++) {
            SpyerWebElementCast SpyerElement = SpyerElements.get(i);
            if (SpyerElement.getRelativePath() == null) {
                for (Map.Entry<String, String> entry : RelativeAbsoluteMapping.entrySet()) {
                    String Absolute = entry.getKey();
                    String Relative = entry.getValue();
                    String AbsoluteValueELementCheck = SpyerElement.getAbsoluteXpath();
                    //System.out.println(SpyerElement.getRelativePath() + "Path Check int : " + SpyerElement.getPathcheckchhar() + "| KeyLength : " + Absolute.length() + " | ElementXpath : " + AbsoluteValueELementCheck + " | CHecked Xpath : " + Absolute + " | Result : " + AbsoluteValueELementCheck.contains(Absolute));
                    if (SpyerElement.getPathcheckchhar() < Absolute.length() && AbsoluteValueELementCheck.contains(Absolute)) {
                        SpyerElement.setRelativePath(AbsoluteValueELementCheck.replace(Absolute, Relative));
                        SpyerElement.setPathcheckchhar(Absolute.length());
                    }

                }
            }
        }
        HashMap<String, ExtentTest> TestMapping = new HashMap<String, ExtentTest>();
        this.ReportURL = this.RepositoryDirectoryPath + "\\" + "XpathRelative.html";
        ExtentReports extent = new ExtentReports(this.ReportURL, true);
        ArrayList<ExtentTest> ETL = new ArrayList<ExtentTest>();
        ExtentTest AllElements = extent.startTest("All Elements");
        ETL.add(AllElements);
        try {
            //FileWriterClass XC = new FileWriterClass();
            //XC.openFileWriter(this.RepositoryDirectoryPath, "XpathData");
            //XC.writenewDataLine("FileName\tAttributeValue\tFolder");
            for (int i = 0; i < SpyerElements.size(); i++) {

                SpyerWebElementCast ELement = SpyerElements.get(i);
                //System.out.println(ELement.getAbsoluteXpath() + " | " + ELement.getElementName() + " | " + ELement.getRelativePath());
                String RelPath = "";
                if (ELement.getRelativePath() == null) {
                    RelPath = ELement.getAbsoluteXpath();
                } else {
                    RelPath = ELement.getRelativePath();
                }
                //XC.writenewDataLine(ELement.getElementName() + "\t" + RelPath + "\t" + ELement.getTagName());
                boolean withoutchild = true, onlydisplayed = true;
                if (OnlyChildless) {
                    withoutchild = ELement.NumberofDirectChilds == 0;
                }
                if (OnlyDisplayed) {
                    onlydisplayed = ELement.isDisplayed;
                }
                if (onlydisplayed && withoutchild) {
                    ExcelOutPutMap.put(ELement.getRelativePath(), ELement);
                    ExtentTest logger = null;
                    String temptagname = ELement.getTagName();
                    if (TestMapping.containsKey(temptagname)) {
                        logger = TestMapping.get(temptagname);
                        //System.out.println("Element Tag name Old : " + temptagname);
                        //ETL.add(logger);
                    } else {
                        logger = extent.startTest(temptagname);
                        TestMapping.put(temptagname, logger);
                        // System.out.println("Element Tag name NewOne : " + temptagname);
                        ETL.add(logger);
                    }
                    String Details = "Filename : " + ELement.getElementName() + " | Absolute Path : " + ELement.getAbsoluteXpath() + " | <h5> Unique Relative Path : " + ELement.getRelativePath() + " </h5>| id : " + ELement.getIDAttribute() + " | name : " + ELement.getNameAttribute()
                            + " | TagName : " + ELement.getTagName() + " | Point : " + ELement.getPoint() + " | Backgroud Color : " + ELement.getRGBBackgroudColor() + " | value : " + ELement.getValue() + " | class : " + ELement.getClassAttribute() + " <h5> " + ELement.getUniqueAttributes() + "<h5>";
                    String screenshotPath = null;
                    if (base64stitch == true) {
                        screenshotPath = elementScreenShot(ELement.getELement(), driver, ELement.getElementName());
                        logger.log(LogStatus.INFO, Details + logger.addBase64ScreenShot(screenshotPath));
                        AllElements.log(LogStatus.INFO, Details + logger.addBase64ScreenShot(screenshotPath));
                    } else {
                        screenshotPath = elementScreenShot(ELement.getELement(), driver, ELement.getElementName());
                        logger.log(LogStatus.INFO, Details + logger.addScreenCapture(screenshotPath));
                        AllElements.log(LogStatus.INFO, Details + logger.addScreenCapture(screenshotPath));
                    }

                }
            }
            //XC.writeandCloseFileWriter();
        } catch (Exception Ex) {
            Ex.printStackTrace();
        } finally {
            for (int i = 0; i < ETL.size(); i++) {
                ExtentTest TestObj = ETL.get(i);
                extent.endTest(TestObj);

            }
            extent.flush();
            extent.close();
            String dateformat = new SimpleDateFormat("yyyyMMdd_hhmmss_SSS").format(new Date());
            if(inputType=="Src") {
            ExcelWriter4ImageAnalyzer.writeToExcel(ExcelOutPutMap, this.RepositoryDirectoryPath + "\\ImageAnalyzer_Src.xlsx");
            
            }
            
            if(inputType=="Target") {
            
            	 ExcelWriter4ImageAnalyzer.writeToExcel(ExcelOutPutMap, this.RepositoryDirectoryPath + "\\ImageAnalyzer_Target.xlsx");
            	
            }
        
        }
        
        return ExcelOutPutMap;
    }

    public void processeachMap(String AttributeValue, ArrayList<SpyerWebElementCast> Data, String AttributeKey) throws IOException {
        SpyerWebElementCast SpyerObject = Data.get(0);
        if (Data.size() == 1) {
            ++count;

            if (AttributeKey.equals("text")) {
                SpyerObject.setRelativePath("*//" + SpyerObject.getTagName() + "[text()='" + AttributeValue + "']");
                RelativeAbsoluteMapping.put(SpyerObject.getAbsoluteXpath(), SpyerObject.getRelativePath());
            } else if (AttributeKey.equals("TagName")) {
                SpyerObject.setRelativePath("*//" + SpyerObject.getTagName());
                RelativeAbsoluteMapping.put(SpyerObject.getAbsoluteXpath(), SpyerObject.getRelativePath());
            } else {
                SpyerObject.setRelativePath("*//" + SpyerObject.getTagName() + "[@" + AttributeKey + "='" + AttributeValue + "']");
                RelativeAbsoluteMapping.put(SpyerObject.getAbsoluteXpath(), SpyerObject.getRelativePath());
            }
            SpyerObject.addUniqueAttributes(AttributeKey);
            ++k;
        }
    }
    int count;

    public void eachMap(String AttributeKey, HashMap<String, ArrayList<SpyerWebElementCast>> EachMap) throws IOException, NoSuchMethodException {

        WorkerThreadManager WTM = new WorkerThreadManager();
        if (AttributeKey.equals("AbsoluteXpath") == false) {
            count = 0;
            for (Map.Entry<String, ArrayList<SpyerWebElementCast>> entry1 : EachMap.entrySet()) {
                String AttributeValue = entry1.getKey();
                ArrayList<SpyerWebElementCast> Data = entry1.getValue();
                WTM.addMethodForExecution(SpyerCore.class, "processeachMap", new Object[]{AttributeValue, Data, AttributeKey}, this);
            }
            WTM.executeThreadsandWaitCompletionFullThrottle();
            System.out.println(count + " Elements have unique " + AttributeKey + " attribute");
        }
    }

    public void iteratePriorities() throws IOException, NoSuchMethodException {
        HashMap<Integer, Entry<String, HashMap<String, ArrayList<SpyerWebElementCast>>>> PriorityMap = new HashMap<Integer, Entry<String, HashMap<String, ArrayList<SpyerWebElementCast>>>>();

        k = 1;
        for (Map.Entry<String, HashMap<String, ArrayList<SpyerWebElementCast>>> entry : AttributesMap.entrySet()) {

            String AttributeKey = entry.getKey();
            switch (AttributeKey) {
            case "type": {
                PriorityMap.put(6, entry);
                break;
            }
                case "TagName": {
                    PriorityMap.put(5, entry);
                    break;
                }
                case "name": {
                    PriorityMap.put(4, entry);
                    break;
                }
                case "class": {
                    PriorityMap.put(3, entry);
                    break;
                }
                case "text": {
                    PriorityMap.put(2, entry);
                    break;
                }
                case "id": {
                    PriorityMap.put(1, entry);
                    break;
                }
            }

        }

        for (int i = 6; i > 0; i--) {
            String AttributeKey = PriorityMap.get(i).getKey();
            HashMap<String, ArrayList<SpyerWebElementCast>> EachMap = PriorityMap.get(i).getValue();
            eachMap(AttributeKey, EachMap);
        }
    }

    public void proccesElement(SpyerWebElementCast ELementName, Integer i, Integer j) {

        System.out.println("Processing Element : " + j);
        String AbsoluteXpath = ELementName.getAbsoluteXpath();
        String ClassAttribute = ELementName.getClassAttribute();
        String TypeAttribute = ELementName.getTypeAttribute();
        String NameAttribute = ELementName.getNameAttribute();
        String IDAttribute = ELementName.getIDAttribute();
        String TagName = ELementName.getTagName();
        String ElementText = ELementName.getElementText();
        SpyerElements.add(ELementName);
        if (AttributesMap.get("TagName").get(TagName) != null) {
            AttributesMap.get("TagName").get(TagName).add(ELementName);
        } else {
            ArrayList<SpyerWebElementCast> ElementData = new ArrayList<SpyerWebElementCast>();
            ElementData.add(ELementName);
            AttributesMap.get("TagName").put(TagName, ElementData);
        }
        if (AttributesMap.get("name").get(NameAttribute) != null) {
            AttributesMap.get("name").get(NameAttribute).add(ELementName);
        } else {
            ArrayList<SpyerWebElementCast> ElementData = new ArrayList<SpyerWebElementCast>();
            ElementData.add(ELementName);
            AttributesMap.get("name").put(NameAttribute, ElementData);
        }
        if (AttributesMap.get("class").get(ClassAttribute) != null) {
            AttributesMap.get("class").get(ClassAttribute).add(ELementName);
        } else {
            ArrayList<SpyerWebElementCast> ElementData = new ArrayList<SpyerWebElementCast>();
            ElementData.add(ELementName);
            AttributesMap.get("class").put(ClassAttribute, ElementData);
        }
        if (AttributesMap.get("id").get(IDAttribute) != null) {
            AttributesMap.get("id").get(IDAttribute).add(ELementName);
        } else {
            ArrayList<SpyerWebElementCast> ElementData = new ArrayList<SpyerWebElementCast>();
            ElementData.add(ELementName);
            AttributesMap.get("id").put(IDAttribute, ElementData);
        }
        
        if (AttributesMap.get("type").get(TypeAttribute) != null) {
            AttributesMap.get("type").get(TypeAttribute).add(ELementName);
        } else {
            ArrayList<SpyerWebElementCast> ElementData = new ArrayList<SpyerWebElementCast>();
            ElementData.add(ELementName);
            AttributesMap.get("type").put(TypeAttribute, ElementData);
        }
       
        if (ELementName.NumberofDirectChilds == 0) {
            if (AttributesMap.get("text").get(ElementText) != null) {
                AttributesMap.get("text").get(ElementText).add(ELementName);
            } else {
                ArrayList<SpyerWebElementCast> ElementData = new ArrayList<SpyerWebElementCast>();
                ElementData.add(ELementName);
                AttributesMap.get("text").put(ElementText, ElementData);
            }
        }
        if (AttributesMap.get("AbsoluteXpath").get(AbsoluteXpath) != null) {
            AttributesMap.get("AbsoluteXpath").get(AbsoluteXpath).add(ELementName);
        } else {
            ArrayList<SpyerWebElementCast> ElementData = new ArrayList<SpyerWebElementCast>();
            ElementData.add(ELementName);
            AttributesMap.get("AbsoluteXpath").put(AbsoluteXpath, ElementData);
        }

    }

    public void setDriver(WebDriver Currentdriver) {
        this.driver = Currentdriver;
    }

    public SpyerCore() {
    }

    public void loadURL(String URL) {
        this.driver.get(URL);
    }

    public void spyCurrentDriverState(WebDriver dri,Boolean onlydisplayed, Boolean onlychildless,String inputType) throws IOException, InterruptedException, NoSuchMethodException {
        this.OnlyChildless = onlychildless;
        this.OnlyDisplayed = onlydisplayed;

        long start = System.currentTimeMillis();
        try {
            AttributesMap = new HashMap<String, HashMap<String, ArrayList<SpyerWebElementCast>>>();
            AttributesMap.put("TagName", new HashMap<String, ArrayList<SpyerWebElementCast>>());
            AttributesMap.put("name", new HashMap<String, ArrayList<SpyerWebElementCast>>());
            AttributesMap.put("class", new HashMap<String, ArrayList<SpyerWebElementCast>>());
            AttributesMap.put("text", new HashMap<String, ArrayList<SpyerWebElementCast>>());
            AttributesMap.put("id", new HashMap<String, ArrayList<SpyerWebElementCast>>());
            AttributesMap.put("type", new HashMap<String, ArrayList<SpyerWebElementCast>>());
            AttributesMap.put("AbsoluteXpath", new HashMap<String, ArrayList<SpyerWebElementCast>>());
            WorkerThreadManager MGR = new WorkerThreadManager();
            Thread.sleep(5000);
            AllElementsofPage = dri.findElements(By.xpath("//*"));
            totalprogresscount = AllElementsofPage.size() + 2;
            System.out.println("Size : " + totalprogresscount);
            int i = 1;
            for (int j = 0; j < AllElementsofPage.size(); j++) {
                WebElement webElement = AllElementsofPage.get(j);
                SpyerWebElementCast ELementName = new SpyerWebElementCast(webElement);

                ELementName.setAbsoluteXpath(getAbsoluteXPath(webElement, dri));

                ELementName.setElementName("Snap" + j);
                currentprogress = i;
                progresspercent = (int) ((currentprogress / totalprogresscount) * 100);
              //  setProgressPercent();
                MGR.addMethodForExecution(SpyerCore.class, "proccesElement", new Object[]{ELementName, i, j}, this);

                ++i;
            }
            MGR.executeThreadsandWaitCompletionFullThrottle();
            System.out.println("Displayed ELements : " + (i - 1));
            iteratePriorities();
            ++currentprogress;
            progresspercent = (int) ((currentprogress / totalprogresscount) * 100);
         //   setProgressPercent();

            generateRelativeXPath(inputType);

        } finally {
            Secondstimetaken = ((System.currentTimeMillis() - start) / 1000);
            System.out.println("Time Taken : " + Secondstimetaken + " seconds");
            ++currentprogress;
            progresspercent = (int) ((currentprogress / totalprogresscount) * 100);
          //  setProgressPercent();
        }
    }

    public void ShutdownBrowser() {
        driver.close();
    }

}
