/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.maveric.webelementComparison;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author temp
 */
public class WorkerThread implements Runnable {

    private Method MethodtoRun;
    private Object[] Arguments;
    private Object CallerObject;

    public <T> T getCastedClassObject(Class<T> Type) {

        return Type.cast(this.CallerObject);
    }

    public WorkerThread(Method RunMethod, Object[] ArgumentsRequired, Object InvokeObject) {
        this.MethodtoRun = RunMethod;
        this.Arguments = ArgumentsRequired;
        this.CallerObject = InvokeObject;

    }

    @Override
    public void run() {
        try {
            /* if (this.Arguments.length == this.MethodtoRun.getParameterCount()) {
                ParameterPassed = new Object[this.Arguments.length];
                Class[] Parametertypes = this.MethodtoRun.getParameterTypes();
                for (int i = 0; i < Parametertypes.length; i++) {
                    Class Parametertype = Parametertypes[i];
                    for (int j = 0; j < Arguments.length; j++) {
                        Object ArgumentObject = Arguments[j];
                        if (Parametertype.equals(ArgumentObject.getClass())) {
                            ParameterPassed[i] = ArgumentObject;
                            break;
                        }
                    }
                }
            }
            System.out.println("Parameter Passed : "+ParameterPassed[0].getClass()+","+ParameterPassed[1].getClass());
            this.MethodtoRun.invoke(MethodtoRun.getClass().newInstance(), ParameterPassed);*/
//            System.out.println("Parameter Passed : "+Arguments[0].getClass()+","+Arguments[1].getClass());
            this.MethodtoRun.invoke(getCastedClassObject(MethodtoRun.getDeclaringClass()), this.Arguments);
            // throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        } catch (IllegalArgumentException | InvocationTargetException | IllegalAccessException ex) {
            Logger.getLogger(WorkerThread.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

}
