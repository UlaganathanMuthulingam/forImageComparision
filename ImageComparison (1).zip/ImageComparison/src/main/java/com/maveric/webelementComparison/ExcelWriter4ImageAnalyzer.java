/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.maveric.webelementComparison;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Set;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

/**
 *
 * @author Dell
 */
public class ExcelWriter4ImageAnalyzer {

    public static void writeToExcel(HashMap<String, SpyerWebElementCast> srcMap, String ExcelPath) {
        XSSFWorkbook workbook = new XSSFWorkbook();
        XSSFSheet sheet = workbook.createSheet("Position Mapping sheet");
        Set<String> keyset = srcMap.keySet();
        //	Set<String> colorKeyset = srcColorMap.keySet();
        int rownum = 1;

        Row header = sheet.createRow(0);
        
        header.createCell(0).setCellValue("Elements Type");
        header.createCell(1).setCellValue("Elements XPath");
        header.createCell(2).setCellValue("Position");
        header.createCell(3).setCellValue("Color");
        header.createCell(4).setCellValue("Text");
        header.createCell(5).setCellValue("Value");
       

        for (String key : keyset) {
            Row row = sheet.createRow(rownum++);
            String type=srcMap.get(key).getTypeAttribute();
            String tagName=srcMap.get(key).getTagName();
            String point = srcMap.get(key).getPoint();
            String color = srcMap.get(key).getRGBBackgroudColor();
            String text = srcMap.get(key).getElementText();
            String value = srcMap.get(key).getValue();
            
            int cellnum = 0;
            Cell cell = row.createCell(cellnum++);
           /* if(key!=null && key.contains("text()"));
            cell.setCellValue("Plain-Text");
           */ if(type!=null && !type.isEmpty() && type.equals("submit"))
            cell.setCellValue("Button");
            else if(type!=null && !type.isEmpty() && type.equals("text"))
            cell.setCellValue("Text-box");
            else if(type!=null && !type.isEmpty() && type.equals("password"))
                cell.setCellValue("Text-box");
            else if(type!=null && !type.isEmpty() && type.equals("checkbox"))
                cell.setCellValue("CheckBox");
            else if(type!=null && !type.isEmpty() && type.equals("radio"))
                cell.setCellValue("RadioButton");
            else if(tagName!=null && !tagName.isEmpty() && tagName.equalsIgnoreCase("select"))
            	cell.setCellValue("DropDown");
            else if(tagName!=null && !tagName.isEmpty() && tagName.equalsIgnoreCase("a"))
            	cell.setCellValue("Link");
            else if(tagName!=null && !tagName.isEmpty() && tagName.equalsIgnoreCase("option"))
            	cell.setCellValue("Drop Down option");
           
            else
            	cell.setCellValue(type);
            
            Cell cell1 = row.createCell(cellnum++);
            cell1.setCellValue(key);
            
            Cell cell2 = row.createCell(cellnum++);
            cell2.setCellValue(point);
            Cell cell3 = row.createCell(cellnum++);
            cell3.setCellValue(color);
            Cell cell4 = row.createCell(cellnum++);
            cell4.setCellValue(text);
            Cell cell5 = row.createCell(cellnum++);
            cell5.setCellValue(value);
            
        }

        try {
            FileOutputStream out = new FileOutputStream(new File(ExcelPath));
            workbook.write(out);
            out.close();
            workbook.close();
            System.out.println("Base Line File generated successfully..");
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
