package com.maveric.webelementComparison;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

import javax.imageio.ImageIO;
import org.apache.commons.io.FileUtils;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.Point;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import com.maveric.webElementComparisonReports.Reporter;
import com.maveric.webelementComparison.SpyerWebElementCast;


public class TargetPageSpyer extends Reporter {

	public RemoteWebDriver driver;
	public static int rowCount;
	private static final String INPUT_FILE_NAME = "D:\\Priya\\SrcPageElements.xlsx";
	String RepositoryDirectoryPathSrc = "D:\\SpyerRepository\\Src";
	String RepositoryDirectoryPathTarget = "D:\\SpyerRepository\\Target";
	public boolean base64stitch = false;
	List<WebElement> AllElementsofPage;
	List<WebElement> AllElementsofTargetPage;

	static Map<String,String> targetMap=new LinkedHashMap<String,String>();
	static Map<String,String> srcMap=new LinkedHashMap<String,String>();
	
	static HashMap<String,String> srcColorMap=new LinkedHashMap<String,String>();
	static HashMap<String,String> targetColorMap=new LinkedHashMap<String,String>();
	
	static HashMap<String,String> srcTextMap=new LinkedHashMap<String,String>();
	static HashMap<String,String> targetTextMap=new LinkedHashMap<String,String>();
	
	private Set<String> notAlignEle;
	private Set<String> colorMismatchedEle;
	private Set<String> textMismatchedEle;


	@BeforeSuite
	public void beforeSuite() {
		startResult();
		startTestCase("WebElement Comparison", "Test description");

	}


	@AfterSuite
	public void afterSuite() throws IOException {
		endTestcase();
		endResult();
		//driver.quit();

	}


	public synchronized String elementScreenShot(WebElement ele, WebDriver driver,String FileName,String Path) throws IOException {
		//String Destinationpath = Path + "\\" + ele.getTagName() + "\\" + FileName + ".png";
		String Destinationpath = Path + "\\" + FileName + ".png";
		try {


			// Get entire page screenshot
			File screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			BufferedImage fullImg = ImageIO.read(screenshot);

			// Get the location of element on the page
			Point point = ele.getLocation();

			// Get width and height of the element
			int eleWidth = ele.getSize().getWidth();
			int eleHeight = ele.getSize().getHeight();

			// Crop the entire page screenshot to get only element screenshot
			BufferedImage eleScreenshot = fullImg.getSubimage(point.getX(), point.getY(),
					eleWidth, eleHeight);
			System.out.println("");
			ImageIO.write(eleScreenshot, "png", screenshot);

			// Copy the element screenshot to disk
			File screenshotLocation = new File(Destinationpath);
			FileUtils.copyFile(screenshot, screenshotLocation);
			/*if (base64stitch == true) {
				FileInputStream FIS = new FileInputStream(screenshot);
				byte[] bytes = new byte[(int) screenshot.length()];
				FIS.read(bytes);
				Destinationpath = "data:image/png;base64," + new String(Base64.encodeBase64(bytes));
			}
			 */
		} catch (Exception Ex) {
			// Ex.printStackTrace();
		} finally {
			return Destinationpath;
		}
	}


	@Test(priority=1)
	public void scanTargetPage() throws IOException, InterruptedException {


		System.out.println("Inside scanTargetPage");
		DesiredCapabilities IEDesiredCapabilities = DesiredCapabilities.internetExplorer();

		IEDesiredCapabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		IEDesiredCapabilities.setCapability(InternetExplorerDriver.INITIAL_BROWSER_URL, "http://www.google.com");
		IEDesiredCapabilities.internetExplorer().setCapability("ignoreProtectedModeSettings", true);
		IEDesiredCapabilities.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
		IEDesiredCapabilities.setJavascriptEnabled(true);
		//IEDesiredCapabilities.setCapability("requireWindowFocus", true);
		IEDesiredCapabilities.setCapability("enablePersistentHover", false);
		System.setProperty("webdriver.ie.driver", "./drivers/iedriver.exe");
		driver =  new InternetExplorerDriver(IEDesiredCapabilities);	
		/*System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		driver = new ChromeDriver();
		*/
		driver.get("http://demo.rapidtestpro.com/admin");
		//Thread.sleep(9000);
		AllElementsofPage=driver.findElements(By.xpath("//*"));
		for (int j = 1; j < AllElementsofPage.size(); j++) {
			WebElement webElement = AllElementsofPage.get(j);
			SpyerWebElementCast ELementName = new SpyerWebElementCast(webElement);
			ELementName.setElementName("Snap"+ j);
			ELementName.setRelativePath(getRelativeXPath(webElement, driver));
			targetMap.put(ELementName.getRelativePath(), webElement.getLocation().toString());	
			targetColorMap.put(ELementName.getRelativePath(), webElement.getCssValue("background-color"));
			targetTextMap.put(ELementName.getRelativePath(), webElement.getText());
			//webElement.getCssValue("");
			//elementScreenShot(ELementName.getELement(), driver,ELementName.getElementName(),RepositoryDirectoryPathTarget); 
		}

		String[][] data=readFromExcel();
		for (String[] row : data) {
			srcMap.put(row[0].replaceAll("\\s+",""), row[1]);
			srcColorMap.put(row[0].replaceAll("\\s+",""), row[2]);
			srcTextMap.put(row[0].replaceAll("\\s+",""), row[3]);



		}

		for (Entry<String, String> entry: srcMap.entrySet()) {
			String key=entry.getKey();
			String value=entry.getValue();
			System.out.println("FromSrcSheetExcel " + key+ "-->" + value);

		}
		
		for (Entry<String, String> entry: srcColorMap.entrySet()) {
			String key=entry.getKey();
			String value=entry.getValue();
			System.out.println("FromSrcColorSheetExcel " + key+ "-->" + value);

		}


		for (Entry<String, String> entry: targetMap.entrySet()) {
			String key=entry.getKey();
			String value=entry.getValue();
			System.out.println("FromTargetMapRunTIme " + key+ "-->" + value);

		}

		
		for (Entry<String, String> entry: targetColorMap.entrySet()) {
			String key=entry.getKey();
			String value=entry.getValue();
			System.out.println("FromTargetColorMapRunTIme " + key+ "-->" + value);

		}

		
		reportStepExpected("Source Image", "INFO");
		notAlignEle=compareMaps(srcMap,targetMap);

		if(!notAlignEle.isEmpty()) 
		{
		
		
		for (String string : notAlignEle) {
			
			
			WebElement element = driver.findElementByXPath(string);
			HighlightElement(driver, element);
			reportStep("The element with xpath " + string + " whose position has changed is highlighted below", "FAIL");
		}
		}

		
		colorMismatchedEle=compareColorMaps(srcColorMap,targetColorMap);

		if(!colorMismatchedEle.isEmpty()) 
		{
		
		for (String string : colorMismatchedEle) {
			//System.out.println("I am here" + string);
			
			WebElement element = driver.findElementByXPath(string);
			HighlightColorElement(driver, element);
			reportStep("The element with xpath " + string + " whose color has changed is highlighted below", "FAIL");
		}
		}


		textMismatchedEle=compareTextMaps(srcTextMap,targetTextMap);

		if(!textMismatchedEle.isEmpty()) 
		{
		
		for (String string : textMismatchedEle) {
			//System.out.println("I am here" + string);
			
			WebElement element = driver.findElementByXPath(string);
			HighlightTextElement(driver, element);
			reportStep("The element with xpath " + string + " whose text has changed is highlighted below", "FAIL");
		}
		}

	}


	public String getRelativeXPath(WebElement element,WebDriver driver) {

		String attribute= element.getAttribute("id");

		String relXpath ="//*[@id='" + attribute + "']";

		return relXpath;
	}

	public static String[][] readFromExcel() {
		//System.out.println("Inside ReadFromExcel");
		String[][] data = null ;

		try {
			FileInputStream fis = new FileInputStream(INPUT_FILE_NAME);
			XSSFWorkbook workbook = new XSSFWorkbook(fis);
			XSSFSheet sheet = workbook.getSheetAt(0);	

			// get the number of rows
			rowCount = sheet.getLastRowNum();

			// get the number of columns
			int columnCount = sheet.getRow(0).getLastCellNum();
			data = new String[rowCount][columnCount];

			//System.out.println(rowCount);
			// loop through the rows
			for(int i=1; i <rowCount+1; i++){
				try {
					XSSFRow row = sheet.getRow(i);
					for(int j=0; j <columnCount; j++){ // loop through the columns
						try {
							String cellValue = "";
							try{
								cellValue = row.getCell(j).getStringCellValue();
							}catch(NullPointerException e){

							}

							data[i-1][j]  = cellValue; // add to the data array
						} catch (Exception e) {
							e.printStackTrace();
						}				
					}

				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			fis.close();
			workbook.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return data;		

	}


	public Set<String> compareMaps(Map<String,String>src, Map<String,String>target) {
		//System.out.println("Inside compareMaps");
		Set<String> notAlignedEle = new HashSet<String>();
		//check both maps are equal
		if(src.equals(target)) {
			reportStep("No Alignment Issue Found", "PASS");
			//System.out.println("No Alignment issue found");
		}

		//If  Both Maps are not equal
		else {

			//check if the key set are same			
			if(target.keySet().equals(src.keySet())) {

				//System.out.println("Keyset same");
				//Adding the keys whose positions doesn't match	
				for (String key: src.keySet()) {
					if (!src.get(key).equals(target.get(key))) {
					//	reportStep(src.get(key), status);
						notAlignedEle.add(key);  
					}

				} 

			}
		}
		return notAlignedEle;
	}

	
	public Set<String> compareColorMaps(Map<String,String>src, Map<String,String>target) {
		Set<String> colorMismatchedEle = new HashSet<String>();
		//check both maps are equal
		if(src.equals(target)) {
			reportStep("No color change among the web elements found", "PASS");
		}

		//If  Both Maps are not equal
		else {

			//check if the key set are same			
			if(target.keySet().equals(src.keySet())) {

				//System.out.println("Keyset same");
				//Adding the keys whose positions doesn't match	
				for (String key: src.keySet()) {
					if (!src.get(key).equals(target.get(key))) {

						colorMismatchedEle.add(key);  
					}

				} 

			}
		}
		return colorMismatchedEle;
	}

	public Set<String> compareTextMaps(Map<String,String>src, Map<String,String>target) {
		Set<String> textMismatchedEle = new HashSet<String>();
		//check both maps are equal
		if(src.equals(target)) {
			reportStep("No Text change among the web elements found", "PASS");
		}

		//If  Both Maps are not equal
		else {

			//check if the key set are same			
			if(target.keySet().equals(src.keySet())) {

				//System.out.println("Keyset same");
				//Adding the keys whose positions doesn't match	
				for (String key: src.keySet()) {
					if (!src.get(key).equals(target.get(key))) {

						textMismatchedEle.add(key);  
					}

				} 

			}
		}
		return textMismatchedEle;
	}

	
	
	
	
	public static void HighlightElement(WebDriver driver, WebElement element){ 
		
		if (driver instanceof JavascriptExecutor) {
			((JavascriptExecutor)driver).executeScript("arguments[0].style.border='3px solid red'", element);
		}

	}
	
	public static void HighlightColorElement(WebDriver driver, WebElement element){ 
		
		if (driver instanceof JavascriptExecutor) {
			((JavascriptExecutor)driver).executeScript("arguments[0].style.border='3px solid blue'", element);
		}

	}

	
public static void HighlightTextElement(WebDriver driver, WebElement element){ 
		
		if (driver instanceof JavascriptExecutor) {
			((JavascriptExecutor)driver).executeScript("arguments[0].style.border='3px solid yellow'", element);
		}

	}

	public static void UnhighlightElement(WebDriver driver, WebElement element){   
		if (driver instanceof JavascriptExecutor) {    
			((JavascriptExecutor)driver).executeScript("arguments[0].style.border=''", element);
		}

	}


	public long takeSnap() {
		long number = (long) Math.floor(Math.random() * 900000000L) + 10000000L;
		try {
			FileUtils.copyFile(driver.getScreenshotAs(OutputType.FILE), new File("./images/" + number + ".png"));
		} catch (WebDriverException e) {
			System.out.println("The browser has been closed.");
			throw e;
		} catch (IOException e) {
			System.out.println("The snapshot could not be taken");

		}
		return number;
	}

}
