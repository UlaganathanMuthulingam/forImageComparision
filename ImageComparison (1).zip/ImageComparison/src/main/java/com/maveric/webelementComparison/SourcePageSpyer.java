package com.maveric.webelementComparison;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;


import javax.imageio.ImageIO;
import org.apache.commons.io.FileUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.Point;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.Test;

import com.maveric.webelementComparison.SpyerWebElementCast;
//import com.praveen.psr.seleniumspyer.ExcelWriter4ImageAnalyzer;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;


public class SourcePageSpyer {

	private static final String FILE_NAME = "D:\\Priya\\SrcPageElements.xlsx";
	String RepositoryDirectoryPathSrc = "D:\\SpyerRepository\\Src";
	public boolean base64stitch = false;
	List<WebElement> AllElementsofPage;
	List<WebElement> AllElementsofTargetPage;	
	static HashMap<String,String> srcMap=new LinkedHashMap<String,String>();
	static HashMap<String,String> srcColorMap=new LinkedHashMap<String,String>();
	static HashMap<String,String> srcTextMap=new LinkedHashMap<String,String>();
	public RemoteWebDriver driver;
	 ArrayList<SpyerWebElementCast> SpyerElements = new ArrayList<SpyerWebElementCast>();
	
	

	public synchronized void elementScreenShot(WebElement ele, WebDriver driver,String FileName,String Path) throws IOException {
		//String Destinationpath = Path + "\\" + ele.getTagName() + "\\" + FileName + ".png";
		String Destinationpath = Path + "\\" + FileName + ".png";
		try {


			// Get entire page screenshot
			File screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			BufferedImage fullImg = ImageIO.read(screenshot);

			// Get the location of element on the page
			Point point = ele.getLocation();

			// Get width and height of the element
			int eleWidth = ele.getSize().getWidth();
			int eleHeight = ele.getSize().getHeight();

			// Crop the entire page screenshot to get only element screenshot
			BufferedImage eleScreenshot = fullImg.getSubimage(point.getX(), point.getY(),
					eleWidth, eleHeight);
			System.out.println("");
			ImageIO.write(eleScreenshot, "png", screenshot);

			// Copy the element screenshot to disk
			File screenshotLocation = new File(Destinationpath);
			FileUtils.copyFile(screenshot, screenshotLocation);
			/*if (base64stitch == true) {
				FileInputStream FIS = new FileInputStream(screenshot);
				byte[] bytes = new byte[(int) screenshot.length()];
				FIS.read(bytes);
				Destinationpath = "data:image/png;base64," + new String(Base64.encodeBase64(bytes));
			}
			 */
		} catch (Exception Ex) {
			 Ex.printStackTrace();
		} 
	}


	@Test(priority=1)
	public void scanSrcPage() throws Exception {

		DesiredCapabilities IEDesiredCapabilities = DesiredCapabilities.internetExplorer();
		IEDesiredCapabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		IEDesiredCapabilities.setCapability(InternetExplorerDriver.INITIAL_BROWSER_URL, "http://www.google.com");
		IEDesiredCapabilities.internetExplorer().setCapability("ignoreProtectedModeSettings", true);
		IEDesiredCapabilities.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
		IEDesiredCapabilities.setJavascriptEnabled(true);
		//IEDesiredCapabilities.setCapability("requireWindowFocus", true);
		IEDesiredCapabilities.setCapability("enablePersistentHover", false);
		System.setProperty("webdriver.ie.driver", "./drivers/iedriver.exe");	
		WebDriver driver =  new InternetExplorerDriver(IEDesiredCapabilities);
		
		/*System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		driver = new ChromeDriver();*/
		
		driver.get("http://demo.rapidtestpro.com/admin");
		takeSnapShot(driver, "./images/Expected.png");
	//	driver.get("https://www.hotcoursesabroad.com/?nr=y");	
		AllElementsofPage=driver.findElements(By.xpath("//*"));
		for (int j = 1; j < AllElementsofPage.size(); j++) {
			WebElement webElement = AllElementsofPage.get(j);
			SpyerWebElementCast ELementName = new SpyerWebElementCast(webElement);
			ELementName.setRelativePath(getRelativeXPath(webElement, driver));
		// ELementName.setAbsoluteXpath(getAbsoluteXPath(webElement, driver));
			ELementName.setElementName("Snap"+ j);		
			srcMap.put(ELementName.getRelativePath(), webElement.getLocation().toString());
			srcTextMap.put(ELementName.getRelativePath(), webElement.getText());
			srcColorMap.put(ELementName.getRelativePath(), webElement.getCssValue("background-color"));
			//elementScreenShot(ELementName.getELement(), driver,ELementName.getElementName(),RepositoryDirectoryPathSrc); 
		}

		writeToExcel(srcMap);
	}


	public void writeToExcel  (HashMap<String,String> srcMap) {
		XSSFWorkbook workbook = new XSSFWorkbook();
		XSSFSheet sheet = workbook.createSheet("Position Mapping sheet");
		Set<String> keyset = srcMap.keySet();
	//	Set<String> colorKeyset = srcColorMap.keySet();
		int rownum = 1;

		Row header = sheet.createRow(0);
		header.createCell(0).setCellValue("Elements XPath");
		header.createCell(1).setCellValue("Position");
		header.createCell(2).setCellValue("Color");
		header.createCell(3).setCellValue("Text");

		for (String key : keyset) {
			Row row = sheet.createRow(rownum++);
			String point = srcMap.get(key);
			String color=srcColorMap.get(key);
			String text=srcTextMap.get(key);
			int cellnum = 0;
			Cell cell = row.createCell(cellnum++);
			cell.setCellValue(key);
			Cell cell1 = row.createCell(cellnum++);
			cell1.setCellValue(point);
			Cell cell2 = row.createCell(cellnum++);
			cell2.setCellValue(color);
			Cell cell3 = row.createCell(cellnum++);
			cell3.setCellValue(text);
		}
				
		try {
			FileOutputStream out = new FileOutputStream(new File(FILE_NAME));
			workbook.write(out);
			out.close();
			workbook.close();
			System.out.println("Excel written successfully..");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public String getRelativeXPath(WebElement element,WebDriver driver) {
		
		String attribute= element.getAttribute("id");
		
		String relXpath ="//*[@id='" + attribute + " ']";
		
		return relXpath;
	}
	
		
	
	public String getAbsoluteXPath(WebElement element, WebDriver driver) {
        return (String) ((JavascriptExecutor) driver).executeScript(
                "function absoluteXPath(element) {"
                + "var comp, comps = [];"
                + "var parent = null;"
                + "var xpath = '';"
                + "var getPos = function(element) {"
                + "var position = 1, curNode;"
                + "if (element.nodeType == Node.ATTRIBUTE_NODE) {"
                + "return null;"
                + "}"
                + "for (curNode = element.previousSibling; curNode; curNode = curNode.previousSibling) {"
                + "if (curNode.nodeName == element.nodeName) {"
                + "++position;"
                + "}"
                + "}"
                + "return position;"
                + "};"
                + "if (element instanceof Document) {"
                + "return '/';"
                + "}"
                + "for (; element && !(element instanceof Document); element = element.nodeType == Node.ATTRIBUTE_NODE ? element.ownerElement : element.parentNode) {"
                + "comp = comps[comps.length] = {};"
                + "switch (element.nodeType) {"
                + "case Node.TEXT_NODE:"
                + "comp.name = 'text()';"
                + "break;"
                + "case Node.ATTRIBUTE_NODE:"
                + "comp.name = '@' + element.nodeName;"
                + "break;"
                + "case Node.PROCESSING_INSTRUCTION_NODE:"
                + "comp.name = 'processing-instruction()';"
                + "break;"
                + "case Node.COMMENT_NODE:"
                + "comp.name = 'comment()';"
                + "break;"
                + "case Node.ELEMENT_NODE:"
                + "comp.name = element.nodeName;"
                + "break;"
                + "}"
                + "comp.position = getPos(element);"
                + "}"
                + "for (var i = comps.length - 1; i >= 0; i--) {"
                + "comp = comps[i];"
                + "xpath += '/' + comp.name.toLowerCase();"
                + "if (comp.position !== null) {"
                + "xpath += '[' + comp.position + ']';"
                + "}"
                + "}"
                + "return xpath;"
                + "} return absoluteXPath(arguments[0]);", element);
    }
	
	
		
	
    public static void takeSnapShot(WebDriver webdriver,String fileWithPath) throws Exception{

        //Convert web driver object to TakeScreenshot

        TakesScreenshot scrShot =((TakesScreenshot)webdriver);

        //Call getScreenshotAs method to create image file

                File SrcFile=scrShot.getScreenshotAs(OutputType.FILE);

            //Move image file to new destination

                File DestFile=new File(fileWithPath);

                //Copy file at destination

                FileUtils.copyFile(SrcFile, DestFile);

    }

}