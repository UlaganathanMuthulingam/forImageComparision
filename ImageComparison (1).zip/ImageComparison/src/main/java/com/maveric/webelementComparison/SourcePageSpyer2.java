package com.maveric.webelementComparison;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;


import javax.imageio.ImageIO;
import org.apache.commons.io.FileUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.Point;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.Test;

import com.maveric.webelementComparison.SpyerWebElementCast;
//import com.praveen.psr.seleniumspyer.ExcelWriter4ImageAnalyzer;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;


public class SourcePageSpyer2 {

	private static final String FILE_NAME = "D:\\Priya\\SrcPageElements.xlsx";
	
	String RepositoryDirectoryPathSrc = "D:\\SpyerRepository\\Src";
	public boolean base64stitch = false;
	List<WebElement> AllElementsofPage;
	List<WebElement> AllElementsofTargetPage;	
	static HashMap<String,String> srcMap=new LinkedHashMap<String,String>();
	static HashMap<String,String> srcColorMap=new LinkedHashMap<String,String>();
	static HashMap<String,String> srcTextMap=new LinkedHashMap<String,String>();
	public static RemoteWebDriver driver;
	 ArrayList<SpyerWebElementCast> SpyerElements = new ArrayList<SpyerWebElementCast>();
	
	

	
	@Test(priority=1)
	public void scanSrcPage(String browser,String URL) throws Exception {

		
		  if (browser.equals("Internet Explorer")) {
		DesiredCapabilities IEDesiredCapabilities = DesiredCapabilities.internetExplorer();
		IEDesiredCapabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		IEDesiredCapabilities.setCapability(InternetExplorerDriver.INITIAL_BROWSER_URL, "http://www.google.com");
		IEDesiredCapabilities.internetExplorer().setCapability("ignoreProtectedModeSettings", true);
		IEDesiredCapabilities.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
		IEDesiredCapabilities.setJavascriptEnabled(true);
		//IEDesiredCapabilities.setCapability("requireWindowFocus", true);
		IEDesiredCapabilities.setCapability("enablePersistentHover", false);
		System.setProperty("webdriver.ie.driver", "./drivers/iedriver.exe");	
		 driver =  new InternetExplorerDriver(IEDesiredCapabilities);
		  }
		  
		  else if(browser.equals("Chrome"))
		  {
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		driver = new ChromeDriver();
		  }
	driver.get(URL);
	//	driver.get("http://testleaf.herokuapp.com/pages/checkbox.html");
	//	driver.get("http://testleaf.herokuapp.com/pages/radio.html");
	//	driver.get("http://testleaf.herokuapp.com/pages/Dropdown.html");
	//	driver.get("https://www.facebook.com/");
		takeSnapShot(driver, "./images/Expected.png");
		SpyerCore X = new SpyerCore();
		X.spyCurrentDriverState(driver,true, false,"Src");
		  }
 
	
    public static void takeSnapShot(WebDriver webdriver,String fileWithPath) throws Exception{

        //Convert web driver object to TakeScreenshot

        TakesScreenshot scrShot =((TakesScreenshot)webdriver);

        //Call getScreenshotAs method to create image file

                File SrcFile=scrShot.getScreenshotAs(OutputType.FILE);

            //Move image file to new destination

                File DestFile=new File(fileWithPath);

                //Copy file at destination

                FileUtils.copyFile(SrcFile, DestFile);

    }
    
    

}