/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.maveric.webelementComparison;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 *
 * @author temp
 */
public class WorkerThreadManager {

    private ArrayList<Runnable> ThreadList = new ArrayList<Runnable>();

    public void executeThreadsandWaitCompletion(int Threshold) {
        ExecutorService executor = Executors.newFixedThreadPool(Threshold);
        for (int j = 0; j < ThreadList.size(); j++) {
            executor.execute(ThreadList.get(j));
        }
        executor.shutdown();
        while (!executor.isTerminated()) {
        }
    }
    
    public void executeThreadsFullThrottle(){
      ExecutorService executor = Executors.newFixedThreadPool(ThreadList.size());
        for (int j = 0; j < ThreadList.size(); j++) {
            executor.execute(ThreadList.get(j));
        }
        executor.shutdown();
    }

    public void executeThreadsandWaitCompletionFullThrottle() {
        executeThreadsandWaitCompletion(ThreadList.size());
    }

    public void addMethodForExecution(Class Classname, String MethodName, Object[] Arguments, Object CallerObject) throws NoSuchMethodException {

        /* Class[] ClassArray = new Class[Arguments.length];
        for (int i = 0; i < Arguments.length; i++) {
            ClassArray[i] = Arguments[i].getClass();
        }
        Method M = Classname.getDeclaredMethod(MethodName, ClassArray);*/
        Method M = null;
        Method[] AllMethods = Classname.getDeclaredMethods();
        for (int i = 0; i < AllMethods.length; i++) {
            Method EachMethod = AllMethods[i];
            if (EachMethod.getName().equals(MethodName)) {
                M = EachMethod;
            }
        }
        WorkerThread SY = new WorkerThread(M, Arguments, CallerObject);
        ThreadList.add(SY);
    }
}
