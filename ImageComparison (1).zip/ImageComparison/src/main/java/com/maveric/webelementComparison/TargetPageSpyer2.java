package com.maveric.webelementComparison;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

import javax.imageio.ImageIO;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.io.FileUtils;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.Point;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import com.maveric.webElementComparisonReports.Reporter;
import com.maveric.webelementComparison.SpyerWebElementCast;


public class TargetPageSpyer2 extends Reporter {

	public static RemoteWebDriver driver;
	public static int rowCount;
	private static final String INPUT_SRC_FILE_NAME = "D:\\SpyerRepository\\Src\\ImageAnalyzer_Src.xlsx";
	private static final String INPUT_TARGET_FILE_NAME = "D:\\SpyerRepository\\Src\\Target\\ImageAnalyzer_Target.xlsx";
	String RepositoryDirectoryPathSrc = "D:\\SpyerRepository\\Src";
	String RepositoryDirectoryPathTarget = "D:\\SpyerRepository\\Target";
	public boolean base64stitch = false;
	List<WebElement> AllElementsofPage;
	List<WebElement> AllElementsofTargetPage;
	public static String browser = "";
	public static String URL = "";
	static Map<String,String> srcMap=new LinkedHashMap<String,String>();	
	static HashMap<String,String> srcColorMap=new LinkedHashMap<String,String>();
	static HashMap<String,String> srcTextMap=new LinkedHashMap<String,String>();
	static HashMap<String,String> srcValueMap=new LinkedHashMap<String,String>();
	
		
	static Map<String,String> targetMap=new HashMap<String,String>();
	static HashMap<String,String> targetColorMap=new LinkedHashMap<String,String>();	
	static HashMap<String,String> targetTextMap=new LinkedHashMap<String,String>();
	static HashMap<String,String> targetValueMap=new LinkedHashMap<String,String>();
	
	private Set<String> notAlignEle;
	private Set<String> colorMismatchedEle;
	private Set<String> textMismatchedEle;
	private Set<String> valueMismatchedEle;


	@BeforeSuite
	public void beforeSuite() {
		startResult();
		startTestCase("WebElement Comparison", "Test description");

	}


	@AfterSuite
	public void afterSuite() throws IOException {
		endTestcase();
		endResult();
		//driver.quit();

	}




	
	@Test(priority=1)
	public void scanTargetPage() throws Exception {

		 if (browser.equals("Internet Explorer")) {
		DesiredCapabilities IEDesiredCapabilities = DesiredCapabilities.internetExplorer();
		IEDesiredCapabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		IEDesiredCapabilities.setCapability(InternetExplorerDriver.INITIAL_BROWSER_URL, "http://www.google.com");
		IEDesiredCapabilities.internetExplorer().setCapability("ignoreProtectedModeSettings", true);
		IEDesiredCapabilities.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
		IEDesiredCapabilities.setJavascriptEnabled(true);
		//IEDesiredCapabilities.setCapability("requireWindowFocus", true);
		IEDesiredCapabilities.setCapability("enablePersistentHover", false);
		System.setProperty("webdriver.ie.driver", "./drivers/iedriver.exe");	
		 driver =  new InternetExplorerDriver(IEDesiredCapabilities);
		 }
		 
		 else if(browser.equalsIgnoreCase("Chrome")) {
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		driver = new ChromeDriver();
		 }
		driver.get(URL);
	//driver.get("D:\\நிர்வாகம் - தேதி.html");
		/*driver.get("http://www.google.com");
		driver.findElementByLinkText("தமிழ்").click();
		WebElement textbox =driver.findElement(By.id("lst-ib"));
		textbox.sendKeys("Maveric");
		textbox.sendKeys(Keys.ENTER);
		Thread.sleep(2000);
		*/
		reportStepExpected("Source Image", "INFO");
	//	takeSnapShot(driver, "./images/Expected.png");
		SpyerCore X = new SpyerCore();
		X.spyCurrentDriverState(driver,true, false,"Target");
		boolean userDefinedOn=false;
		copyFromSrcExcelToMap(userDefinedOn);
		copyFromTargetExcelToMap(userDefinedOn);
		findDisJunction(srcMap,targetMap);
		highlightMismatches();
		
 }	

	
	
		public void copyFromSrcExcelToMap(Boolean userDefined) {
		String[][] data=readFromSrcExcel();
		for (String[] row : data) {

			if(userDefined)
			{
				if(!row[0].isEmpty()) {
			srcMap.put(row[1].replaceAll("\\s+",""), row[2]);
			srcColorMap.put(row[1].replaceAll("\\s+",""), row[3]);
			srcTextMap.put(row[1].replaceAll("\\s+",""), row[4]);
			srcValueMap.put(row[1].replaceAll("\\s+",""), row[5]);
				}
			}
			
			if(!userDefined)
			{
				
			srcMap.put(row[1].replaceAll("\\s+",""), row[2]);
			srcColorMap.put(row[1].replaceAll("\\s+",""), row[3]);
			srcTextMap.put(row[1].replaceAll("\\s+",""), row[4]);
			srcValueMap.put(row[1].replaceAll("\\s+",""), row[5]);
				
			}
		}
		
		
/*	for (Entry<String, String> entry: srcMap.entrySet()) {
			String key=entry.getKey();
			String value=entry.getValue();
			System.out.println("FromSrcSheetExcel " + key+ "-->" + value);

		}
		
		for (Entry<String, String> entry: srcColorMap.entrySet()) {
			String key=entry.getKey();
			String value=entry.getValue();
			System.out.println("FromSrcColorSheetExcel " + key+ "-->" + value);

		}

		
		for (Entry<String, String> entry: srcTextMap.entrySet()) {
			String key=entry.getKey();
			String value=entry.getValue();
			System.out.println("FromSrcTextSheetExcel " + key+ "-->" + value);

		}

*/		}
			
				
		public void copyFromTargetExcelToMap(Boolean userDefined) {
			String[][] data=readFromTargetExcel();
			for (String[] row : data) {
				if(userDefined)
				{
					if(!row[0].isEmpty())
					{
				targetMap.put(row[1].replaceAll("\\s+",""), row[2]);
				targetColorMap.put(row[1].replaceAll("\\s+",""), row[3]);
				targetTextMap.put(row[1].replaceAll("\\s+",""), row[4]);
				targetValueMap.put(row[1].replaceAll("\\s+",""), row[5]);
				}
				}
				if(!userDefined)
				{
					
				targetMap.put(row[1].replaceAll("\\s+",""), row[2]);
				targetColorMap.put(row[1].replaceAll("\\s+",""), row[3]);
				targetTextMap.put(row[1].replaceAll("\\s+",""), row[4]);
				targetValueMap.put(row[1].replaceAll("\\s+",""), row[5]);
				}
			}

			

		/*	for (Entry<String, String> entry: targetMap.entrySet()) {
				String key=entry.getKey();
				String value=entry.getValue();
				System.out.println("FromtargetSheetExcel " + key+ "-->" + value);

			}
			
			for (Entry<String, String> entry: targetColorMap.entrySet()) {
				String key=entry.getKey();
				String value=entry.getValue();
				System.out.println("FromtargetColorSheetExcel " + key+ "-->" + value);

			}

			
			for (Entry<String, String> entry: targetTextMap.entrySet()) {
				String key=entry.getKey();
				String value=entry.getValue();
				System.out.println("FromtargetTextSheetExcel " + key+ "-->" + value);

			}
*/
		}

		
				
	
		
		public void highlightMismatches() {
			
		notAlignEle=compareMaps(srcMap,targetMap);

		if(!notAlignEle.isEmpty()) 
		{
		
		
		for (String string : notAlignEle) {
			
			
			WebElement element = driver.findElementByXPath(string);
			HighlightElement(driver, element);
			reportStep("The element with xpath " + string + " whose position has changed is highlighted in red below", "FAIL");
		}
		}

		
		colorMismatchedEle=compareColorMaps(srcColorMap,targetColorMap);

		if(!colorMismatchedEle.isEmpty()) 
		{
		
		for (String string : colorMismatchedEle) {
			//System.out.println("I am here" + string);
			
			WebElement element = driver.findElementByXPath(string);
			HighlightColorElement(driver, element);
			reportStep("The element with xpath " + string + " whose color has changed is highlighted in blue below", "FAIL");
		}
		}


		textMismatchedEle=compareTextMaps(srcTextMap,targetTextMap);

		if(!textMismatchedEle.isEmpty()) 
		{
		
		for (String string : textMismatchedEle) {
			WebElement element = driver.findElementByXPath(string);
			HighlightTextElement(driver, element);
			reportStep("The element with xpath " + string + " whose text has changed is highlighted in yellow below", "FAIL");
		}
		}
		
		
		valueMismatchedEle=compareValueMaps(srcValueMap,targetValueMap);

		if(!valueMismatchedEle.isEmpty()) 
		{
		
		for (String string : valueMismatchedEle) {
			WebElement element = driver.findElementByXPath(string);
			HighlightValueElement(driver, element);
			reportStep("The element with xpath " + string + " whose value has changed is highlighted in pink below", "FAIL");
		}
		}

	}


	
	public static String[][] readFromSrcExcel() {
		//System.out.println("Inside ReadFromExcel");
		String[][] data = null ;

		try {
			FileInputStream fis = new FileInputStream(INPUT_SRC_FILE_NAME);
			XSSFWorkbook workbook = new XSSFWorkbook(fis);
			XSSFSheet sheet = workbook.getSheetAt(0);	

			// get the number of rows
			rowCount = sheet.getLastRowNum();

			// get the number of columns
			int columnCount = sheet.getRow(0).getLastCellNum();
			data = new String[rowCount][columnCount];

			//System.out.println(rowCount);
			// loop through the rows
			for(int i=1; i <rowCount+1; i++){
				try {
					XSSFRow row = sheet.getRow(i);
					for(int j=0; j <columnCount; j++){ // loop through the columns
						try {
							String cellValue = "";
							try{
								cellValue = row.getCell(j).getStringCellValue();
							}catch(NullPointerException e){

							}

							data[i-1][j]  = cellValue; // add to the data array
						} catch (Exception e) {
							e.printStackTrace();
						}				
					}

				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			fis.close();
			workbook.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return data;		

	}


	
	public static String[][] readFromTargetExcel() {
		//System.out.println("Inside ReadFromExcel");
		String[][] data = null ;

		try {
			FileInputStream fis = new FileInputStream(INPUT_TARGET_FILE_NAME);
			XSSFWorkbook workbook = new XSSFWorkbook(fis);
			XSSFSheet sheet = workbook.getSheetAt(0);	

			// get the number of rows
			rowCount = sheet.getLastRowNum();

			// get the number of columns
			int columnCount = sheet.getRow(0).getLastCellNum();
			data = new String[rowCount][columnCount];

			//System.out.println(rowCount);
			// loop through the rows
			for(int i=1; i <rowCount+1; i++){
				try {
					XSSFRow row = sheet.getRow(i);
					for(int j=0; j <columnCount; j++){ // loop through the columns
						try {
							String cellValue = "";
							try{
								cellValue = row.getCell(j).getStringCellValue();
							}catch(NullPointerException e){

							}

							data[i-1][j]  = cellValue; // add to the data array
						} catch (Exception e) {
							e.printStackTrace();
						}				
					}

				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			fis.close();
			workbook.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return data;		

	}

	
	public void findDisJunction(Map<String,String>src, Map<String,String>target) {
		
		for (String key: src.keySet()) {
		      if (!target.containsKey(key)) {
		    	  reportStep("The element with xpath " + key + " is missing in the target page when comapared against source","FAIL");
		    	  
		      }
		      
		   		   } 
		
		for (String key: target.keySet()) {
		      if (!src.containsKey(key)) {
		    	  reportStep("The element with xpath " + key + " which is present in the target is not present in the source","FAIL");
		    	  
		      }
		      
		   		   } 
	
	}
	public Set<String> compareMaps(Map<String,String>src, Map<String,String>target) {
		//System.out.println("Inside compareMaps");
		Set<String> notAlignedEle = new HashSet<String>();
		
		//check both maps are equal
		if(src.equals(target)) {
			reportStep("No Alignment Issue Found", "PASS");
			//System.out.println("No Alignment issue found");
		}

		//If  Both Maps are not equal
		else {

			//check if the key set are same			
			if(target.keySet().equals(src.keySet())) {

				//System.out.println("Keyset same");
				//Adding the keys whose positions doesn't match	
				for (String key: src.keySet()) {
					if (!src.get(key).equals(target.get(key))) {
						notAlignedEle.add(key);  
					}

				} 

			}
					
		}
		return notAlignedEle;
	}

	
	public Set<String> compareColorMaps(Map<String,String>src, Map<String,String>target) {
		Set<String> colorMismatchedEle = new HashSet<String>();
		//check both maps are equal
		if(src.equals(target)) {
			reportStep("No color change found", "PASS");
		}

		//If  Both Maps are not equal
		else {

			//check if the key set are same			
			if(target.keySet().equals(src.keySet())) {

				//System.out.println("Keyset same");
				//Adding the keys whose positions doesn't match	
				for (String key: src.keySet()) {
					if (!src.get(key).equals(target.get(key))) {

						colorMismatchedEle.add(key);  
					}

				} 

			}
		}
		return colorMismatchedEle;
	}

	public Set<String> compareTextMaps(Map<String,String>src, Map<String,String>target) {
		Set<String> textMismatchedEle = new HashSet<String>();
		//check both maps are equal
		if(src.equals(target)) {
			reportStep("No Text change found", "PASS");
		}

		//If  Both Maps are not equal
		else {

			//check if the key set are same			
			if(target.keySet().equals(src.keySet())) {

				//System.out.println("Keyset same");
				//Adding the keys whose positions doesn't match	
				for (String key: src.keySet()) {
					if (!src.get(key).equals(target.get(key))) {

						textMismatchedEle.add(key);  
					}

				} 

			}
		}
		return textMismatchedEle;
	}

	
	
	public Set<String> compareValueMaps(Map<String,String>src, Map<String,String>target) {
		Set<String> valueMismatchedEle = new HashSet<String>();
		//check both maps are equal
		if(src.equals(target)) {
			reportStep("No Value change found", "PASS");
		}

		//If  Both Maps are not equal
		else {

			//check if the key set are same			
			if(target.keySet().equals(src.keySet())) {

				//System.out.println("Keyset same");
				//Adding the keys whose positions doesn't match	
				for (String key: src.keySet()) {
					if (!src.get(key).equals(target.get(key))) {

						valueMismatchedEle.add(key);  
					}

				} 

			}
		}
		return valueMismatchedEle;
	}

	
	public static void HighlightElement(WebDriver driver, WebElement element){ 
		
		if (driver instanceof JavascriptExecutor) {
			((JavascriptExecutor)driver).executeScript("arguments[0].style.border='3px solid red'", element);
		}

	}
	
	public static void HighlightColorElement(WebDriver driver, WebElement element){ 
		
		if (driver instanceof JavascriptExecutor) {
			((JavascriptExecutor)driver).executeScript("arguments[0].style.border='3px solid blue'", element);
		}

	}

	
public static void HighlightTextElement(WebDriver driver, WebElement element){ 
		
		if (driver instanceof JavascriptExecutor) {
			((JavascriptExecutor)driver).executeScript("arguments[0].style.border='3px solid yellow'", element);
		}

	}


public static void HighlightValueElement(WebDriver driver, WebElement element){ 
	
	if (driver instanceof JavascriptExecutor) {
		((JavascriptExecutor)driver).executeScript("arguments[0].style.border='3px solid pink'", element);
	}

}


	public static void UnhighlightElement(WebDriver driver, WebElement element){   
		if (driver instanceof JavascriptExecutor) {    
			((JavascriptExecutor)driver).executeScript("arguments[0].style.border=''", element);
		}

	}


	public long takeSnap() {
		long number = (long) Math.floor(Math.random() * 900000000L) + 10000000L;
		try {
			FileUtils.copyFile(driver.getScreenshotAs(OutputType.FILE), new File("./images/" + number + ".png"));
		} catch (WebDriverException e) {
			System.out.println("The browser has been closed.");
			throw e;
		} catch (IOException e) {
			System.out.println("The snapshot could not be taken");

		}
		return number;
	}

}
