/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.maveric.webelementComparison;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

/**
 *
 * @author temp
 */
public class SpyerWebElementCast {

    private WebElement ELement;
    private String ElementName;
    private String AbsoluteXpath;
    private String RelativePath;
    private String ClassAttribute;
    private String TypeAttribute;
   
	private String NameAttribute;
    private String IDAttribute;
    private String TagName;
    private String ElementText;
    private String Value;
    private String UniqueAttributes = " | ";


	private String Point;
    private String RGBBackgroudColor;
   
   
	int NumberofDirectChilds;
    public boolean isDisplayed;
    private int pathcheckchhar = 0;

    public SpyerWebElementCast(WebElement WB) {
        this.ELement = WB;
        this.NumberofDirectChilds = WB.findElements(By.xpath("*")).size();
        this.isDisplayed = this.ELement.isDisplayed();
        this.ClassAttribute = WB.getAttribute("class");
        this.TypeAttribute=WB.getAttribute("type");
        this.NameAttribute = WB.getAttribute("name");
        this.IDAttribute = WB.getAttribute("id");
        this.Value = WB.getAttribute("value");
        this.TagName = WB.getTagName();
        this.Point = WB.getLocation().toString();
        this.RGBBackgroudColor = WB.getCssValue("background-color");
       
        //System.out.println(this.TagName+" || "+WB.getText());
        if (this.NumberofDirectChilds == 0 && this.isDisplayed == true) {
            String Data = WB.getAttribute("textContent");
            this.ElementText = Data;
            if (Data.trim().length() == 0) {
                this.ElementText = "";
            }
           // System.out.println("Element Text : " + this.ElementText);
        }
    }

    public String getPoint() {
		return Point;
	}

	public String getRGBBackgroudColor() {
		return RGBBackgroudColor;
	}
    
	
	 public String getTypeAttribute() {
			return TypeAttribute;
		}

    public WebElement getELement() {
        return ELement;
    }

    public void setELement(WebElement ELement) {

        this.ELement = ELement;
    }

    public String getElementName() {
        return ElementName;
    }

    public void setElementName(String Ele) {
        this.ElementName = Ele;
        //this.ElementName = ElementName + this.TagName + this.ElementText + this.IDAttribute + this.NameAttribute;
    }

    public String getAbsoluteXpath() {
        return AbsoluteXpath;
    }

    public void setAbsoluteXpath(String AbsoluteXpath) {
        this.AbsoluteXpath = AbsoluteXpath;
    }

    public String getRelativePath() {
        return RelativePath;
    }

    public void setRelativePath(String RelativePath) {
        this.RelativePath = RelativePath;
    }

    public int getPathcheckchhar() {
        return pathcheckchhar;
    }

    public void setPathcheckchhar(int pathcheckchhar) {
        this.pathcheckchhar = pathcheckchhar;
    }

    public String getClassAttribute() {
        return ClassAttribute;
    }

    public String getNameAttribute() {
        return NameAttribute;
    }

    public String getIDAttribute() {
        return IDAttribute;
    }

    public String getTagName() {
        return TagName;
    }

    public String getElementText() {
        return ElementText;
    }

    public String getValue() {
        return Value;
    }

    public String getUniqueAttributes() {
        return UniqueAttributes;
    }

    public void addUniqueAttributes(String UniqueAttributes) {
        this.UniqueAttributes += UniqueAttributes + " | ";
    }

}
